import { useState } from "react";
import { MapPin, ChevronDown, ShoppingBag, History, Sparkles, Navigation } from "lucide-react";
import { LocationProfile, CartItem } from "../types";
import { locationProfiles } from "../data";

interface NavbarProps {
  currentLocation: LocationProfile;
  onChangeLocation: (location: LocationProfile) => void;
  activeTab: "home" | "history" | "tracking";
  setActiveTab: (tab: "home" | "history" | "tracking") => void;
  cart: CartItem[];
  setIsCartOpen: (open: boolean) => void;
  onOpenStoreWithId: (id: string, branchId: string) => void;
}

export default function Navbar({
  currentLocation,
  onChangeLocation,
  activeTab,
  setActiveTab,
  cart,
  setIsCartOpen,
  onOpenStoreWithId
}: NavbarProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const cartTotalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2.5 cursor-pointer" onClick={() => setActiveTab("home")}>
            <div className="h-9 w-9 bg-red-600 rounded-full flex items-center justify-center shadow-lg shadow-red-600/20 relative shrink-0">
              <div className="h-4 w-4 bg-white rounded-full flex items-center justify-center">
                <div className="h-1.5 w-1.5 bg-red-600 rounded-full"></div>
              </div>
            </div>
            <span className="font-black text-xl tracking-tight text-gray-900 shrink-0">
              Go<span className="text-red-600 font-bold">Food</span>
            </span>
          </div>

          {/* Location Selector System */}
          <div className="relative flex-1 max-w-sm sm:max-w-md mx-4 sm:mx-8">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full flex items-center justify-between px-3 py-1.5 sm:px-4 sm:py-2 bg-emerald-50 text-emerald-900 border border-emerald-100 rounded-full hover:bg-emerald-100/70 transition-all text-xs sm:text-sm font-medium text-left"
              id="location-selector"
            >
              <div className="flex items-center space-x-2 truncate pr-2">
                <MapPin className="h-4 w-4 text-emerald-600 shrink-0" />
                <span className="truncate">
                  Anter ke: <strong className="text-emerald-950 font-bold">{currentLocation.label}</strong>
                </span>
              </div>
              <ChevronDown className={`h-4 w-4 text-emerald-700 shrink-0 transition-transform ${isDropdownOpen ? "rotate-180" : ""}`} />
            </button>

            {isDropdownOpen && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-100 rounded-2xl shadow-xl z-50 p-2 overflow-hidden transition-all duration-200">
                <div className="p-2.5 pb-2 text-xs font-semibold text-gray-400 flex items-center space-x-1 uppercase tracking-wider">
                  <Navigation className="h-3 w-3" />
                  <span>Daftar Alamat Kamu</span>
                </div>
                <div className="space-y-1">
                  {locationProfiles.map((loc) => (
                    <button
                      key={loc.id}
                      onClick={() => {
                        onChangeLocation(loc);
                        setIsDropdownOpen(false);
                      }}
                      className={`w-full text-left p-3 rounded-xl transition-all flex flex-col ${
                        loc.id === currentLocation.id
                          ? "bg-emerald-50/80 border-l-4 border-emerald-600"
                          : "hover:bg-gray-50 bg-white"
                      }`}
                    >
                      <span className="text-xs sm:text-sm font-bold text-gray-800 flex items-center">
                        {loc.label}
                        {loc.id === currentLocation.id && (
                          <span className="ml-2 bg-emerald-600 text-white font-semibold text-[9px] px-1.5 py-0.5 rounded-full">
                            Aktif
                          </span>
                        )}
                      </span>
                      <span className="text-xs text-gray-500 truncate mt-1">{loc.address}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Nav Icons and Action Triggers */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            <button
              onClick={() => setActiveTab("home")}
              className={`p-2 rounded-full font-medium transition-all text-xs sm:text-sm flex items-center space-x-1 ${
                activeTab === "home"
                  ? "bg-emerald-600 text-white"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Sparkles className="h-4 w-4" />
              <span className="hidden md:inline">Eksplor</span>
            </button>

            <button
              onClick={() => setActiveTab("history")}
              className={`p-2 rounded-full font-medium transition-all text-xs sm:text-sm flex items-center space-x-1 relative ${
                activeTab === "history"
                  ? "bg-emerald-600 text-white"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <History className="h-4 w-4" />
              <span className="hidden md:inline">Riwayat</span>
            </button>

            {/* Shopping Bag Trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="p-2 bg-gray-50 border border-gray-100 rounded-full hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-100 transition-all text-gray-600 relative flex items-center justify-center"
              id="shopping-bag-btn"
            >
              <ShoppingBag className="h-5 w-5" />
              {cartTotalItems > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white font-bold text-[10px] h-5 w-5 rounded-full flex items-center justify-center animate-pulse border-2 border-white">
                  {cartTotalItems}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
