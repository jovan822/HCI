export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number; // in IDR (Rupiah)
  originalPrice?: number;
  image: string;
  category: string;
  isPopular?: boolean;
  isFlashSale?: boolean;
  discountPercentage?: number;
  tags?: string[];
  customizationOptions?: {
    name: string;
    choices: string[];
    required: boolean;
  }[];
}

export interface Branch {
  id: string;
  name: string; // e.g. "S Parman", "Tanjung Duren", "Cideng Jakarta", "Jalan Panjang"
  address: string;
  distance: number; // in km
  avgDeliveryTime: string; // e.g. "15-25 min"
  rating: number;
  ratingCount: string; // e.g. "4rb+ ratings"
  deliveryFee: number;
  deliveryFeeOriginal?: number;
  promos: string[];
  isOpen: boolean;
}

export interface Restaurant {
  id: string;
  brandName: string; // e.g. "KFC", "Sec Bowl", "Mie Gacoan", "JCO"
  logo: string;
  bannerImage: string;
  categoryTags: string[];
  isHalal: boolean;
  rating: number; // Average or main rating
  isPlusMember?: boolean;
  branches: Branch[];
  menu: MenuItem[];
}

export interface CartItem {
  menuItem: MenuItem;
  restaurantId: string;
  restaurantName: string;
  branchId: string;
  branchName: string;
  quantity: number;
  notes: string;
  selectedCustomizations: { [optionName: string]: string };
}

export interface OrderInvoice {
  subtotal: number;
  deliveryFee: number;
  restaurantServiceFee: number; // e.g. Rp 3.000
  platformFee: number; // e.g. Rp 1.000
  deliveryDiscount: number; // e.g. -Rp 10.000
  promoDiscount: number; // e.g. -Rp 23.400
  total: number;
}

export interface OrderHistoryItem {
  id: string;
  restaurantName: string;
  branchName: string;
  logo: string;
  date: string;
  status: "Selesai" | "Dibatalkan";
  itemsSummary: string; // e.g. "1 Donuts 2 Dzn"
  totalPrice: number;
  savedAmount: number; // e.g. 35790 for "Hemat 35.79rb"
  items: { name: string; quantity: number; price: number; notes?: string }[];
  rating?: number; // User feedback rating
  branchId: string;
  restaurantId: string;
}

export interface OngoingOrder {
  id: string;
  restaurantName: string;
  branchName: string;
  logo: string;
  orderCode: string; // e.g. "GF-546"
  driverName: string;
  driverPhoto: string;
  driverPlate: string;
  driverRating: number;
  driverPhone: string;
  status: "Diproses Resto" | "Driver Menjemput" | "Diantar" | "Sampai";
  statusText: string;
  eta: string;
  currentPin: "resto" | "on_the_way" | "delivered";
  items: { name: string; quantity: number; price: number; notes?: string }[];
  invoice: OrderInvoice;
  customerAddress: string;
  driverNote: string;
}

export interface LocationProfile {
  id: string;
  label: string; // e.g. "Kost Twins Residence", "Ruang Rasa, Blok D", "Kantor Pusat"
  address: string;
}
