import { useState, useEffect, FormEvent } from "react";
import { 
  MapPin, CheckCircle2, Navigation, MessageSquare, Phone, 
  ChevronDown, ChevronUp, User, ShieldCheck, HelpCircle, RefreshCw 
} from "lucide-react";
import { OngoingOrder } from "../types";
import SafeImage from "./SafeImage";

interface LiveTrackingViewProps {
  order: OngoingOrder;
  onSimulateNextStage: () => void;
  onCancelOrder: () => void;
}

export default function LiveTrackingView({ order, onSimulateNextStage, onCancelOrder }: LiveTrackingViewProps) {
  const [isInvoiceExpanded, setIsInvoiceExpanded] = useState(true);
  const [chatMessage, setChatMessage] = useState("");
  const [chatLog, setChatLog] = useState<string[]>(["Halo kak, pesanan sedang disiapkan ya.", "Saya langsung meluncur ke resto."]);

  const handleSendChat = (e: FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;
    setChatLog((prev) => [...prev, chatMessage]);
    const messageToSend = chatMessage;
    setChatMessage("");

    // Simulate driver reply
    setTimeout(() => {
      setChatLog((prev) => [
        ...prev,
        `Okey siap kak, mohon ditunggu sebentar ya 👍 (Balasan Otomatis)`
      ]);
    }, 1500);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString("id-ID");
  };

  // Simulated progress stages
  const stages = [
    { title: "Pesanan Diproses", desc: "Chef sedang menyajikan hidangan lezatmu", active: true },
    { title: "Driver Menjemput", desc: `${order.driverName} sedang mengambil makanan di resto`, active: order.status !== "Diproses Resto" },
    { title: "Makanan Diantar", desc: "Driver berkendara menuju alamat hunianmu", active: order.status === "Diantar" || order.status === "Sampai" },
    { title: "Sampai Tujuan", desc: "Makanan lezatmu sudah tiba di titik lokasi!", active: order.status === "Sampai" }
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
      {/* Simulation Banner Controller */}
      <div className="bg-emerald-900 text-white rounded-3xl p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-center sm:text-left">
          <span className="bg-emerald-700 text-emerald-100 font-extrabold text-[9px] uppercase px-2 py-1 rounded-md tracking-wider">
            ⚙️ PANEL SIMULATOR GO-GRAB
          </span>
          <h3 className="font-bold text-sm sm:text-base mt-1">Uji Alur Pengantaran Driver Real-Time</h3>
          <p className="text-xs text-emerald-250 mt-0.5">Ubah status pesanan untuk berpindah milestone peta lokasi!</p>
        </div>

        <div className="flex gap-2 w-full sm:w-auto">
          {order.status !== "Sampai" ? (
            <button
              onClick={onSimulateNextStage}
              className="flex-1 sm:flex-none bg-emerald-500 hover:bg-emerald-600 font-black text-xs px-4 py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-all cursor-pointer shadow-md"
            >
              <RefreshCw className="h-4 w-4 animate-spin" />
              <span>Simulasikan Tahap Selanjutnya ({order.status})</span>
            </button>
          ) : (
            <span className="bg-emerald-600 border border-emerald-400/30 text-white text-xs font-black px-4 py-2.5 rounded-xl flex items-center justify-center space-x-1.5">
              <span>🎉 Selesai Diantar!</span>
            </span>
          )}
          
          {order.status !== "Sampai" && (
            <button
              onClick={onCancelOrder}
              className="bg-red-500 hover:bg-red-600 font-bold text-xs px-3 py-2.5 rounded-xl cursor-pointer"
            >
              Batal
            </button>
          )}
        </div>
      </div>

      {/* Main Track Info */}
      <div className="bg-white rounded-3xl border border-gray-155 shadow-xl overflow-hidden">
        {/* Status bar */}
        <div className="bg-emerald-50 border-b border-emerald-100 p-5 flex flex-col sm:flex-row justify-between items-center gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <span className="h-2 w-2 rounded-full bg-emerald-600 animate-pulse"></span>
              <span className="text-xs font-extrabold text-emerald-700 tracking-wider uppercase">Order Active Tracking</span>
            </div>
            <h2 className="text-lg font-black text-gray-900 mt-1">{order.statusText}</h2>
          </div>
          <div className="text-center sm:text-right">
            <span className="text-[10px] text-gray-400 font-bold uppercase block">Estimasi Tiba</span>
            <span className="text-lg font-black text-emerald-700">{order.eta}</span>
          </div>
        </div>

        {/* Mini Peta / Progress Bar steps layout */}
        <div className="p-5 bg-gray-50 border-b border-gray-100">
          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-4">Milestone Progress</h4>
          
          <div className="grid grid-cols-4 gap-1.5 relative">
            <div className="col-span-4 h-1.5 bg-gray-200 rounded-full absolute top-[14px] left-3 right-3 -z-10"></div>
            {stages.map((stg, i) => (
              <div key={i} className="flex flex-col items-center">
                <div className={`h-8 w-8 rounded-full border-2 flex items-center justify-center font-black text-xs transition-all ${
                  stg.active
                    ? "bg-emerald-600 border-white text-white shadow-md shadow-emerald-500/20"
                    : "bg-white border-gray-200 text-gray-400"
                }`}>
                  {stg.active ? "✓" : i + 1}
                </div>
                <span className={`text-[10px] font-bold text-center mt-2 ${stg.active ? "text-gray-900" : "text-gray-400"}`}>
                  {stg.title}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Source & Destination Details, mirroring screenshot #7 */}
        <div className="p-5 space-y-4 border-b border-gray-100">
          {/* Outlet Source */}
          <div className="flex items-start">
            <div className="relative flex flex-col items-center shrink-0 mr-4">
              <div className="h-9 w-9 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center border-2 border-white shadow-xs z-10 font-bold text-xs">
                ☕
              </div>
              <div className="w-0.5 bg-dashed border-r border-gray-300 flex-1 min-h-[25px] mt-1"></div>
            </div>
            <div className="flex-1 min-w-0">
              <span className="text-[9px] font-black tracking-widest text-blue-600 block">TITIK PENJEMPUTAN RESTORAN</span>
              <h4 className="font-extrabold text-gray-950 text-sm mt-0.5">{order.restaurantName} - {order.branchName}</h4>
              <p className="text-xs text-gray-500 truncate mt-1">Gojek Merchant Partner, Kemanggisan Raya</p>
            </div>
          </div>

          {/* Delivery Point destination */}
          <div className="flex items-start">
            <div className="relative flex flex-col items-center shrink-0 mr-4">
              <div className="h-9 w-9 bg-red-100 text-red-600 rounded-full flex items-center justify-center border-2 border-white shadow-xs z-10 font-bold text-xs">
                📍
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <span className="text-[9px] font-black tracking-widest text-red-600 block">ALAMAT TUJUAN KAMU</span>
              <h4 className="font-extrabold text-gray-950 text-sm mt-0.5">{order.customerAddress}</h4>
              <p className="text-xs text-gray-500 truncate mt-1">Kemanggisan, Palmerah, Jakarta Barat</p>
            </div>
          </div>

          {/* Special note */}
          <div className="bg-gray-50 rounded-2xl p-4 border border-gray-150">
            <span className="text-[9px] font-black text-gray-400 tracking-wider block uppercase">Catatan Untuk Driver</span>
            <p className="text-xs text-gray-700 font-bold mt-1 inline-block">
              👉 "{order.driverNote}"
            </p>
          </div>
        </div>

        {/* Driver Profile, Card & Real Chat screen! */}
        <div className="p-5 bg-gradient-to-br from-emerald-50/50 to-white flex flex-col sm:flex-row gap-5 items-center justify-between">
          <div className="flex items-center space-x-3.5 w-full sm:w-auto">
            <SafeImage
              type="avatar"
              src={order.driverPhoto}
              alt={order.driverName}
              className="h-14 w-14 rounded-2xl object-cover shrink-0 border border-emerald-100 p-0.5 shadow-sm bg-white"
            />
            <div>
              <div className="flex items-center space-x-2">
                <span className="bg-emerald-600 text-white font-extrabold text-[9px] uppercase px-1.5 py-0.2 rounded-sm">
                  Mitra Driver Gojek
                </span>
                <span className="text-xs text-gray-550 font-medium">⭐ {order.driverRating}</span>
              </div>
              <h4 className="font-extrabold text-gray-900 text-sm sm:text-base mt-0.5">{order.driverName}</h4>
              <p className="text-xs text-gray-550 font-black tracking-wide text-emerald-800">{order.driverPlate}</p>
            </div>
          </div>

          <div className="flex space-x-2.5 w-full sm:w-auto justify-end">
            <button className="flex-1 sm:flex-initial py-2 px-3 bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 rounded-xl font-bold text-xs flex items-center justify-center space-x-1.5 focus:ring-2 focus:ring-emerald-500">
              <Phone className="h-3.5 w-3.5 text-emerald-600" />
              <span>Hubungi</span>
            </button>
            <div className="bg-emerald-600 text-white p-2.5 rounded-xl">
              <ShieldCheck className="h-4 w-4" />
            </div>
          </div>
        </div>

        {/* Real Dynamic Driver Chat widget in the tracking screen */}
        <div className="p-4 bg-gray-50 border-t border-gray-100 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-gray-500 flex items-center">
              <MessageSquare className="h-3.5 w-3.5 text-emerald-600 mr-1" />
              <span>Kirim pesan singkat untuk {order.driverName}</span>
            </span>
            <span className="text-emerald-600 font-bold text-[10px] animate-pulse">Online</span>
          </div>

          {/* Chat Messages Log */}
          <div className="bg-white border border-gray-150 p-3 rounded-2xl max-h-[140px] overflow-y-auto space-y-2 text-xs">
            {chatLog.map((chat, idx) => {
              const isMe = idx % 2 === 0 && idx !== 0 && idx !== 1 ? true : false;
              // Even are typically user, let's just make it clear
              const isDriver = !isMe;
              return (
                <div key={idx} className={`flex flex-col ${isDriver ? "items-start" : "items-end"}`}>
                  <span className="text-[9px] text-gray-400 font-medium pb-0.5">{isDriver ? order.driverName : "Saya"}</span>
                  <div className={`p-2 rounded-xl max-w-[85%] font-medium ${
                    isDriver
                      ? "bg-gray-100 text-gray-800 rounded-tl-none"
                      : "bg-emerald-600 text-white rounded-tr-none"
                  }`}>
                    {chat}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Chat suggestions */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {["Ditunggu ya pak.", "Sesuai peta ya.", "Pake kembalian?", "Makasih kak!"].map((sug) => (
              <button
                key={sug}
                onClick={() => {
                  setChatLog((prev) => [...prev, sug]);
                  setTimeout(() => {
                    setChatLog((prev) => [...prev, "Siap dipahami kak! 👍"]);
                  }, 1200);
                }}
                className="bg-white border border-gray-200 hover:border-emerald-300 hover:bg-emerald-50 text-gray-600 px-3 py-1.5 rounded-full text-[10px] sm:text-xs shrink-0 font-medium select-none cursor-pointer"
              >
                {sug}
              </button>
            ))}
          </div>

          {/* Chat Form */}
          <form onSubmit={handleSendChat} className="flex gap-2">
            <input
              type="text"
              placeholder="Ketik pesan balasan..."
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              className="flex-1 bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
            <button 
              type="submit" 
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 rounded-xl text-xs flex items-center justify-center shrink-0 cursor-pointer"
            >
              Kirim
            </button>
          </form>
        </div>
      </div>

      {/* Expandable Order Detail section & Invoice System */}
      <div className="bg-white rounded-3xl border border-gray-155 shadow-xl overflow-hidden">
        <button
          onClick={() => setIsInvoiceExpanded(!isInvoiceExpanded)}
          className="w-full p-5 flex items-center justify-between font-black text-gray-900 border-b border-gray-100 hover:bg-gray-50/50 transition-all text-sm sm:text-base cursor-pointer"
        >
          <div className="flex items-center space-x-2">
            <span>🧾 Detail Pesanan</span>
            <span className="text-gray-405 text-xs font-normal">({order.orderCode})</span>
          </div>
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-600">
            <span>{isInvoiceExpanded ? "Tutup" : "Buka Detail"}</span>
            {isInvoiceExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </div>
        </button>

        {isInvoiceExpanded && (
          <div className="p-5 space-y-4 animate-in fade-in duration-255 text-xs sm:text-sm">
            {/* List items */}
            <div className="space-y-3 pb-3 border-b border-gray-100">
              {order.items.map((it, id) => (
                <div key={id} className="flex justify-between items-start">
                  <div className="min-w-0 pr-3">
                    <div className="font-bold text-gray-900 flex items-center">
                      <span className="text-emerald-700 font-extrabold mr-1.5">{it.quantity}x</span>
                      <span className="truncate">{it.name}</span>
                    </div>
                    {it.notes && (
                      <span className="text-[10px] text-gray-450 italic block mt-0.5">Note: "{it.notes}"</span>
                    )}
                  </div>
                  <span className="font-bold text-gray-950 shrink-0">Rp {formatPrice(it.price * it.quantity)}</span>
                </div>
              ))}
            </div>

            {/* Price breakdown */}
            <div className="space-y-1.5 text-gray-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>Rp {formatPrice(order.invoice.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Ongkos kirim (Delivery)</span>
                <span>Rp {formatPrice(order.invoice.deliveryFee)}</span>
              </div>
              <div className="flex justify-between">
                <span>Biaya layanan mitra & resto</span>
                <span>Rp {formatPrice(order.invoice.restaurantServiceFee)}</span>
              </div>
              <div className="flex justify-between">
                <span>Biaya platform</span>
                <span>Rp {formatPrice(order.invoice.platformFee)}</span>
              </div>

              {order.invoice.deliveryDiscount < 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>Diskon Ongkos Kirim</span>
                  <span>-Rp {formatPrice(Math.abs(order.invoice.deliveryDiscount))}</span>
                </div>
              )}

              {order.invoice.promoDiscount > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>Diskon Voucher Makanan</span>
                  <span>-Rp {formatPrice(order.invoice.promoDiscount)}</span>
                </div>
              )}

              <hr className="my-2 border-gray-105" />

              <div className="flex justify-between text-sm sm:text-base font-black text-gray-950 pt-1">
                <span>Total Pembayaran</span>
                <span className="text-emerald-700">Rp {formatPrice(order.invoice.total)}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="text-center py-4">
        <p className="text-xs text-gray-400">Butuh bantuan darurat terkait orderan kamu? Hubungi</p>
        <button className="text-emerald-600 text-xs font-bold mt-1.5 underline hover:text-emerald-700 flex items-center justify-center mx-auto space-x-1">
          <HelpCircle className="h-3.5 w-3.5" />
          <span>Layanan Pengaduan GoFood 24 Jam</span>
        </button>
      </div>
    </div>
  );
}
