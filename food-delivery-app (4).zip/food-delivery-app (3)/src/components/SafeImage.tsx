import React, { useState } from "react";
import { ImageIcon, User, Layers } from "lucide-react";

interface SafeImageProps {
  src?: string;
  alt?: string;
  className?: string;
  type?: "logo" | "banner" | "food" | "avatar";
  [key: string]: any;
}

// Solid, high-availability premium Unsplash fallback placeholders
const FALLBACKS = {
  logo: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=120&auto=format&fit=crop&q=80",
  banner: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&auto=format&fit=crop&q=80",
  food: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=300&auto=format&fit=crop&q=80",
  avatar: "https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=120&auto=format&fit=crop&q=80",
};

export default function SafeImage({ 
  src, 
  alt = "Image", 
  className = "", 
  type = "food", 
  ...props 
}: SafeImageProps) {
  const [errorHappened, setErrorHappened] = useState(false);

  // If source is missing or empty, directly use the beautiful fallback
  const finalSrc = !src || errorHappened ? FALLBACKS[type] : src;

  const handleError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    if (!errorHappened) {
      setErrorHappened(true);
    }
  };

  return (
    <img
      src={finalSrc}
      alt={alt}
      className={className}
      onError={handleError}
      referrerPolicy="no-referrer"
      {...props}
    />
  );
}
