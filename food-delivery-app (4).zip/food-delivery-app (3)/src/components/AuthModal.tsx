import React, { useState, useEffect } from "react";
import { X, Mail, Lock, User as UserIcon, Phone, AlertCircle, Eye, EyeOff, Sparkles, Check, LogIn } from "lucide-react";
import { User } from "../types";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

// Default test account for swift demo onboarding
const DEMO_ACCOUNTS = [
  { name: "Jovan", email: "jovan@gmail.com", password: "password123", phone: "081234567890" }
];

export default function AuthModal({ isOpen, onClose, onLoginSuccess }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  // Clear states when toggling login/register
  useEffect(() => {
    setError("");
    setSuccess("");
    // Clear inputs
    if (isOpen) {
      setEmail("");
      setPassword("");
      setName("");
      setPhone("");
    }
  }, [isLogin, isOpen]);

  if (!isOpen) return null;

  // Initialize registered users in localStorage if empty
  const getRegisteredUsers = () => {
    const local = localStorage.getItem("gofood_registered_users");
    if (!local) {
      localStorage.setItem("gofood_registered_users", JSON.stringify(DEMO_ACCOUNTS));
      return DEMO_ACCOUNTS;
    }
    try {
      const parsed = JSON.parse(local);
      // Remove deprecated demo accounts to refresh user state
      const filtered = parsed.filter((u: any) => u.email !== "gofood@go.id" && u.email !== "nov@gmail.com");
      if (!filtered.some((u: any) => u.email === "jovan@gmail.com")) {
        const updated = [...DEMO_ACCOUNTS, ...filtered];
        localStorage.setItem("gofood_registered_users", JSON.stringify(updated));
        return updated;
      }
      return parsed;
    } catch {
      return DEMO_ACCOUNTS;
    }
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    // Subtle timeout to simulate real network request
    setTimeout(() => {
      const users = getRegisteredUsers();

      if (isLogin) {
        // Validate Login
        if (!email || !password) {
          setError("Email dan password wajib diisi.");
          setLoading(false);
          return;
        }

        const foundUser = users.find(
          (u: any) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
        );

        if (foundUser) {
          const authenticatedUser: User = {
            id: foundUser.email,
            name: foundUser.name,
            email: foundUser.email,
            phone: foundUser.phone,
            avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
          };
          localStorage.setItem("gofood_current_user", JSON.stringify(authenticatedUser));
          setSuccess(`Selamat datang kembali, ${foundUser.name}!`);
          setTimeout(() => {
            onLoginSuccess(authenticatedUser);
            onClose();
          }, 1000);
        } else {
          setError("Email atau sandi salah. Coba: jovan@gmail.com / password123");
        }
      } else {
        // Validate Register
        if (!name || !email || !password || !phone) {
          setError("Semua kolom pendaftaran wajib diisi!");
          setLoading(false);
          return;
        }

        // Basic validations
        if (!email.includes("@")) {
          setError("Format alamat email belum valid.");
          setLoading(false);
          return;
        }

        if (password.length < 6) {
          setError("Kata sandi minimal berisi 6 karakter.");
          setLoading(false);
          return;
        }

        // Check duplicates
        const exists = users.some((u: any) => u.email.toLowerCase() === email.toLowerCase());
        if (exists) {
          setError("Email ini sudah terdaftar. Silakan login.");
          setLoading(false);
          return;
        }

        // Save fresh user
        const newUser = { name, email, password, phone };
        const updatedUsers = [...users, newUser];
        localStorage.setItem("gofood_registered_users", JSON.stringify(updatedUsers));

        const authenticatedUser: User = {
          id: email,
          name: name,
          email: email,
          phone: phone,
          avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
        };
        localStorage.setItem("gofood_current_user", JSON.stringify(authenticatedUser));

        setSuccess("Pendaftaran berhasil! Menyambungkan sesi...");
        setTimeout(() => {
          onLoginSuccess(authenticatedUser);
          onClose();
        }, 1200);
      }
      setLoading(false);
    }, 800);
  };

  const loadQuickDemo = (demo: typeof DEMO_ACCOUNTS[0]) => {
    setEmail(demo.email);
    setPassword(demo.password);
    setIsLogin(true);
    setError("");
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" id="auth-modal-screen">
      {/* Dimmed backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Main card box container */}
      <div className="relative bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-gray-100 flex flex-col z-10 transition-all transform scale-100 max-h-[90vh]">
        
        {/* Banner with branding */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white p-6 relative">
          <button 
            onClick={onClose} 
            className="absolute top-4 right-4 bg-white/15 hover:bg-white/30 text-white p-2 rounded-full transition-colors"
            aria-label="Tutup"
            id="close-auth-modal"
          >
            <X className="h-5 w-5" />
          </button>
          
          <div className="flex items-center space-x-2 mb-2">
            <span className="bg-white/20 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider">
              GoFood Akun
            </span>
          </div>
          <h2 className="text-xl font-black tracking-tight" id="auth-modal-title">
            {isLogin ? "Selamat Datang Kembali!" : "Daftar Akun Baru"}
          </h2>
          <p className="text-xs text-red-100 mt-1">
            {isLogin 
              ? "Masuk untuk memesan makanan terlezat dari Sec Bowl, KFC, Fore Coffee & JCO." 
              : "Bikin akun sekarang untuk melacak pesanan praktis dan klaim vocer diskon."}
          </p>
        </div>

        {/* Scrollable form interface body */}
        <div className="overflow-y-auto p-5 sm:p-6 space-y-5">
          {error && (
            <div className="bg-red-50 text-red-800 p-3.5 rounded-2xl border border-red-100 text-xs flex items-start space-x-2.5 animate-pulse" id="auth-error-msg">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="bg-emerald-50 text-emerald-800 p-3.5 rounded-2xl border border-emerald-100 text-xs flex items-start space-x-2.5" id="auth-success-msg">
              <Check className="h-4 w-4 shrink-0 mt-0.5 text-emerald-600" />
              <span className="font-medium">{success}</span>
            </div>
          )}

          <form onSubmit={handleAuthSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider block">
                  Nama Lengkap
                </label>
                <div className="relative">
                  <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-gray-400" />
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Jovan"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-gray-255 rounded-2xl text-sm focus:bg-white focus:ring-2 focus:ring-red-500/10 focus:border-red-500 outline-none transition-all font-medium"
                    id="input-auth-name"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-600 uppercase tracking-wider block">
                Alamat Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-gray-400" />
                <input
                  type="email"
                  required
                  placeholder="name@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-gray-255 rounded-2xl text-sm focus:bg-white focus:ring-2 focus:ring-red-500/10 focus:border-red-500 outline-none transition-all font-medium"
                  id="input-auth-email"
                />
              </div>
            </div>

            {!isLogin && (
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider block">
                  Nomor Telepon (HP)
                </label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-gray-400" />
                  <input
                    type="tel"
                    required
                    placeholder="08xxxxxxxxxx"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-gray-255 rounded-2xl text-sm focus:bg-white focus:ring-2 focus:ring-red-500/10 focus:border-red-500 outline-none transition-all font-medium"
                    id="input-auth-phone"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">
                  Kata Sandi
                </label>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-gray-400" />
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="Min. 6 karakter"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-11 py-2.5 bg-gray-50 border border-gray-255 rounded-2xl text-sm focus:bg-white focus:ring-2 focus:ring-red-500/10 focus:border-red-500 outline-none transition-all font-medium"
                  id="input-auth-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 rounded"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3 px-4 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-2xl shadow-lg shadow-red-600/15 transition-all text-sm flex items-center justify-center space-x-2 mt-2 ${
                loading ? "opacity-75 cursor-not-allowed" : "hover:scale-[1.01]"
              }`}
              id="submit-auth-btn"
            >
              {loading ? (
                <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn className="h-4 w-4" />
                  <span>{isLogin ? "Masuk ke Akun" : "Daftar Akun"}</span>
                </>
              )}
            </button>
          </form>

          {/* Footer toggle screen */}
          <div className="pt-3 text-center text-xs text-gray-500" id="auth-toggle-tip">
            {isLogin ? (
              <p>
                Belum punya akun?{" "}
                <button
                  onClick={() => setIsLogin(false)}
                  className="text-red-600 font-black hover:underline cursor-pointer"
                  type="button"
                  id="btn-switch-to-register"
                >
                  Daftar Sekarang
                </button>
              </p>
            ) : (
              <p>
                Sudah punya akun?{" "}
                <button
                  onClick={() => setIsLogin(true)}
                  className="text-red-600 font-black hover:underline cursor-pointer"
                  type="button"
                  id="btn-switch-to-login"
                >
                  Masuk di sini
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
