import { useState } from "react";
import { Star, CheckCircle, Ticket, Sparkles, Clock, ChevronDown, ChevronUp, ShoppingBag } from "lucide-react";
import { OrderHistoryItem } from "../types";
import SafeImage from "./SafeImage";

interface OrderHistoryViewProps {
  history: OrderHistoryItem[];
  onReorder: (item: OrderHistoryItem) => void;
  onRateOrder: (orderId: string, rating: number) => void;
}

export default function OrderHistoryView({ history, onReorder, onRateOrder }: OrderHistoryViewProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString("id-ID");
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-5">
      {/* Promotion banner for loyalty stars */}
      <div className="bg-gradient-to-r from-orange-500 to-amber-500 p-5 rounded-3xl text-white shadow-lg space-y-1.5 shrink-0">
        <span className="bg-white/20 text-white font-extrabold text-[9px] uppercase px-2 py-0.5 rounded-full tracking-wider">
          Loyalty Star Rewards
        </span>
        <h3 className="font-extrabold text-base sm:text-lg flex items-center space-x-1.5">
          <Sparkles className="h-5 w-5 fill-amber-300 text-amber-200" />
          <span>Beri Rating Bintang Untuk Tambahan Gopay Coins!</span>
        </h3>
        <p className="text-xs text-amber-50 leading-relaxed">
          Setiap ulasan bintang 5 kamu untuk driver dan restoran membantu meningkatkan layanan mitra instan kami.
        </p>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="font-black text-gray-900 text-lg sm:text-xl">Riwayat Pesanan</h2>
        <span className="text-xs font-semibold text-gray-550 bg-gray-100 px-3 py-1 rounded-full">
          Total {history.length} Kuliner Selesai
        </span>
      </div>

      <div className="space-y-4">
        {history.map((order) => {
          const isExpanded = expandedId === order.id;

          return (
            <div
              key={order.id}
              className="bg-white border border-gray-150 rounded-3xl shadow-xs hover:shadow-md transition-all overflow-hidden"
            >
              <div className="p-4 sm:p-5 flex items-start gap-4">
                {/* Logo */}
                <SafeImage
                  type="logo"
                  src={order.logo}
                  alt={order.restaurantName}
                  className="h-12 w-12 rounded-xl object-cover border border-gray-100 p-0.5 bg-gray-50 shrink-0"
                />

                {/* Right text layout matches screenshot #6 exactly */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center justify-between gap-1.5">
                    <div>
                      <h3 className="font-extrabold text-gray-900 text-sm sm:text-base leading-tight hover:text-emerald-700 transition-colors">
                        {order.restaurantName} - {order.branchName}
                      </h3>
                      <p className="text-xs text-gray-400 mt-1 flex items-center">
                        <Clock className="h-3.5 w-3.5 mr-1" />
                        {order.date}
                      </p>
                    </div>

                    {/* Savings tag badge (e.g. Hemat 35.79rb or Hemat 24.5rb) */}
                    {order.savedAmount > 0 && (
                      <span className="bg-emerald-50 text-emerald-800 border-l-4 border-emerald-500 text-[10px] sm:text-xs font-black px-2.5 py-1 rounded-r-lg shrink-0 flex items-center space-x-1 shadow-sm">
                        <Ticket className="h-3 w-3 text-emerald-600 mr-0.5" />
                        <span>Hemat {(order.savedAmount / 1000).toFixed(2)}rb</span>
                      </span>
                    )}
                  </div>

                  {/* Summary of items purchased */}
                  <p className="text-xs text-gray-600 font-bold mt-2.5 bg-gray-50 p-2 rounded-xl border border-gray-100">
                    💡 {order.itemsSummary}
                  </p>

                  {/* Pricing row with details toggle */}
                  <div className="flex items-center justify-between mt-4">
                    <div className="text-xs text-gray-550">
                      Total Bayar: <strong className="text-gray-950 font-black text-sm sm:text-base">Rp {formatPrice(order.totalPrice)}</strong>
                    </div>

                    <button
                      onClick={() => toggleExpand(order.id)}
                      className="text-xs text-gray-450 hover:text-gray-700 font-bold flex items-center space-x-1"
                    >
                      <span>{isExpanded ? "Tutup detail" : "Lihat item detail"}</span>
                      {isExpanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                    </button>
                  </div>

                  <hr className="my-3.5 border-gray-100" />

                  {/* Feedback Stars & Reorder button */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 shrink-0 pt-1">
                    {/* Feedback Rating - Users can tap stars to review! */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Beri Rating Kamu</span>
                      <div className="flex items-center space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={() => onRateOrder(order.id, star)}
                            className="focus:scale-110 active:scale-95 transition-transform"
                          >
                            <Star
                              className={`h-5 w-5 cursor-pointer ${
                                star <= (order.rating || 0)
                                  ? "text-amber-400 fill-amber-400 font-black"
                                  : "text-gray-250 hover:text-amber-200"
                              }`}
                            />
                          </button>
                        ))}
                        {order.rating && (
                          <span className="text-xs text-amber-800 font-black ml-1.5 bg-amber-50 px-1.5 py-0.5 rounded-md">
                            {order.rating}.0 Bintang
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Reorder Button */}
                    <button
                      onClick={() => onReorder(order)}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-4.5 py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-all shadow-md shadow-emerald-600/10 active:scale-95 cursor-pointer"
                    >
                      <ShoppingBag className="h-3.5 w-3.5" />
                      <span>Reorder ("Pesan lagi")</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Collapsible item pricing details */}
              {isExpanded && (
                <div className="bg-gray-50 border-t border-gray-100 p-4 sm:p-5 space-y-2.5 text-xs sm:text-sm animate-in slide-in-from-top-2 duration-200">
                  <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-wider">RINCIAN STRUK BELANJA</h4>
                  
                  {order.items.map((item, id) => (
                    <div key={id} className="flex justify-between items-center text-gray-700">
                      <div>
                        <span className="font-black text-gray-900 mr-2">{item.quantity}x</span>
                        <span className="font-medium">{item.name}</span>
                        {item.notes && <span className="text-[10px] text-orange-600 block pl-6">Note: "{item.notes}"</span>}
                      </div>
                      <span className="font-extrabold text-gray-950">Rp {formatPrice(item.price * item.quantity)}</span>
                    </div>
                  ))}

                  <div className="border-t border-gray-200/50 pt-2 flex items-center justify-between text-[11px] text-gray-450">
                    <span className="flex items-center space-x-1">
                      <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                      <span className="font-bold text-emerald-700">GoFood Certified Delivery Merchant</span>
                    </span>
                    <span>Order No: {order.id}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
