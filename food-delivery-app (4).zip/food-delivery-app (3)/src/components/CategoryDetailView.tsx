import { useState } from "react";
import { ArrowLeft, Star, Clock, BadgePercent, SlidersHorizontal, Check } from "lucide-react";
import { Restaurant, Branch } from "../types";
import SafeImage from "./SafeImage";

interface CategoryDetailViewProps {
  categoryId: string;
  categoryName: string;
  restaurants: Restaurant[];
  onBack: () => void;
  onSelectRestaurant: (restaurant: Restaurant, branch: Branch) => void;
}

export default function CategoryDetailView({
  categoryId,
  categoryName,
  restaurants,
  onBack,
  onSelectRestaurant
}: CategoryDetailViewProps) {
  // Local Filter States
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);

  // Match restaurants that belong to this category
  const categoryRestaurants = restaurants.filter((r) => {
    // 1. Direct tag matching
    const hasTag = r.categoryTags.some(
      (tag) => 
        tag.toLowerCase() === categoryName.toLowerCase() || 
        tag.toLowerCase() === categoryId.toLowerCase().replace("_", " ")
    );
    if (hasTag) return true;

    // 2. Specific matching fallback helper
    const normalizedName = categoryName.toLowerCase();
    const normalizedId = categoryId.toLowerCase();

    if (normalizedId === "viral" || normalizedName.includes("viral")) {
      return r.rating >= 4.8;
    }
    if (normalizedId === "jajanan" || normalizedName.includes("jajanan")) {
      return r.categoryTags.some((t) => ["Jajanan", "Sweets", "Donuts", "Desserts", "Bakery", "Dimsum"].includes(t));
    }
    if (normalizedId === "cepat_saji" || normalizedName.includes("cepat saji") || normalizedName.includes("fast")) {
      return r.categoryTags.some((t) => ["Cepat saji", "Fast Food", "Ayam Geprek"].includes(t));
    }
    if (normalizedId === "korean" || normalizedName.includes("korea") || normalizedName.includes("japan") || normalizedName.includes("jepang")) {
      return r.categoryTags.some((t) => ["Korea", "Jepang", "Sushi", "Bento"].includes(t));
    }
    if (normalizedId === "nasi" || normalizedName.includes("nasi")) {
      return r.categoryTags.some((t) => ["Aneka nasi", "Nasi Cup", "Bento"].includes(t));
    }
    if (normalizedId === "sweets" || normalizedName.includes("sweets") || normalizedName.includes("sweet")) {
      return r.categoryTags.some((t) => ["Sweets", "Donuts", "Desserts", "Bakery"].includes(t));
    }
    if (normalizedId === "minuman" || normalizedName.includes("minuman") || normalizedName.includes("teh") || normalizedName.includes("es")) {
      return r.categoryTags.some((t) => ["Minuman", "Kopi", "Es Segar"].includes(t));
    }
    if (normalizedId === "kopi" || normalizedName.includes("kopi")) {
      return r.categoryTags.some((t) => ["Kopi", "Kopi Lokal"].includes(t));
    }
    if (normalizedId === "geprek" || normalizedName.includes("geprek") || normalizedName.includes("ayam")) {
      return r.categoryTags.some((t) => ["Ayam Geprek", "Ayam", "Ayam Goreng"].includes(t));
    }
    if (normalizedId === "malaysia" || normalizedName.includes("malaysia")) {
      return ["mie-gacoan", "nyambel-rampai"].includes(r.id);
    }

    return false;
  });

  // Apply filters on the list
  const filteredList = categoryRestaurants.filter((resto) => {
    if (!selectedFilter) return true;
    if (selectedFilter === "dibawah_5rb") {
      const primaryBranch = resto.branches[0];
      return primaryBranch.deliveryFee <= 4500;
    }
    if (selectedFilter === "menu_30rb") {
      return resto.menu.some((item) => item.price <= 35000);
    }
    if (selectedFilter === "diskon_40") {
      return resto.branches[0].promos.some(
        (p) => p.toLowerCase().includes("50%") || p.toLowerCase().includes("40%") || p.toLowerCase().includes("31%") || p.toLowerCase().includes("diskon")
      );
    }
    if (selectedFilter === "rating_high") {
      return resto.rating >= 4.9;
    }
    return true;
  });

  // Describe subtext dynamically based on category
  const getSubtext = () => {
    switch (categoryId) {
      case "viral":
        return "Sedang hits, paling direview & direkomendasikan foodies";
      case "jajanan":
        return "Camilan ringan, gorengan, & takjil gurih pas buat ngumpul";
      case "cepat_saji":
        return "Santapan lezat segar siap saji, langsung meluncur panas-panas";
      case "korean":
        return "Aneka ramyeon kuah pedas, bento set & sushi lezat";
      case "nasi":
        return "Menu nasi mangkok, ayam bumbu melimpah bikin kenyang pol";
      case "sweets":
        return "Donat artisan, cake manis, & hidangan penutup penenang jiwa";
      case "minuman":
        return "Pelepas dahaga segar, jus buah, bubble tea & es kopi";
      case "kopi":
        return "Espresso wangi, kopi aren legendaris racikan barista lokal";
      case "geprek":
        return "Ayam goreng tepung digeprek garing berselimut sambal rawit merah";
      case "malaysia":
        return "Masakan khas melayu kaya rempah gurih aromatik menggoda selera";
      default:
        return `Pilihan kuliner terbaik untuk kategori ${categoryName}`;
    }
  };

  return (
    <div className="space-y-6" id={`category-detail-container-${categoryId}`}>
      {/* Back Button & Header Area */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="h-10 w-10 bg-white hover:bg-gray-100 text-gray-800 rounded-full flex items-center justify-center shadow-md border border-gray-100 transition-all cursor-pointer"
          id="btn-back-to-home"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h2 className="text-lg font-black text-gray-900 leading-tight">Kategori: {categoryName}</h2>
          <p className="text-xs text-gray-500 font-semibold">{getSubtext()}</p>
        </div>
      </div>

      {/* REPRODUCING SCREENSHOT HERO BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white shadow-xl">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-white via-red-900 to-black"></div>
        
        {/* Banner Content Layout */}
        <div className="p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
          <div className="space-y-4 max-w-md text-left">
            <span className="bg-[#bdfcb8] text-gray-950 font-black text-[11px] sm:text-xs px-3.5 py-1.5 rounded-sm border-2 border-black uppercase tracking-wider shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] inline-block">
              Beli makan siang
            </span>
            <div className="bg-white text-gray-950 font-black text-xl sm:text-3xl p-4 rounded-2xl shadow-lg border-2 border-gray-900 rotate-[-1deg] leading-tight">
              Selalu ada <span className="text-red-600">ONGKIR</span> <span className="text-emerald-700">MURAAAH</span>
            </div>
          </div>

          {/* Go Food Graphic Representation */}
          <div className="flex items-center space-x-4 shrink-0 bg-white/10 p-3 sm:p-4 rounded-3xl border border-white/20 backdrop-blur-xs">
            {/* Driver & Delivery Visual Overlay */}
            <div className="flex -space-x-4">
              <div className="h-14 w-14 rounded-full border-2 border-white bg-emerald-600 flex items-center justify-center text-white font-bold shadow-md text-xs text-center p-1 uppercase leading-none">
                🛵 Gojek Driver
              </div>
              <div className="h-14 w-14 rounded-full border-2 border-white bg-red-600 flex items-center justify-center text-white font-bold shadow-md text-xs text-center p-1 uppercase leading-none">
                🛍️ GoFood Bag
              </div>
            </div>
            
            <div className="text-left">
              <div className="text-xs font-black uppercase text-yellow-300 flex items-center space-x-1">
                <span>★ Super Hemat</span>
              </div>
              <p className="text-[11px] text-white/90 font-medium max-w-[150px] mt-0.5">
                Driver berjaket Gojek siap antar makananmu super cepat & higienis!
              </p>
            </div>

            {/* Waving Cat Icon */}
            <div className="text-4xl animate-bounce">
              🐱
            </div>
          </div>
        </div>
      </div>

      {/* HEADER TITLES */}
      <div className="text-left space-y-1">
        <h3 className="text-xl font-black text-gray-900 tracking-tight">Resto enaaak, ongkir muraaah</h3>
        <p className="text-xs text-gray-500 font-medium">Pas buat bukber! Ongkir minimal, silaturahmi maksimal.</p>
      </div>

      {/* FILTER PILLS BUTTONS ROW (mirrors screenshot) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none" id="categories-filter-bar">
        <button
          onClick={() => setSelectedFilter(null)}
          className={`p-2.5 rounded-full border transition-all shrink-0 flex items-center justify-center ${
            !selectedFilter 
              ? "bg-emerald-600 text-white border-emerald-600" 
              : "bg-white text-gray-600 border-gray-200 hover:border-gray-400"
          }`}
        >
          <SlidersHorizontal className="h-4 w-4" />
        </button>

        <button
          onClick={() => setSelectedFilter(selectedFilter === "dibawah_5rb" ? null : "dibawah_5rb")}
          className={`px-4 py-2 rounded-full border text-xs font-bold transition-all shrink-0 flex items-center space-x-1.5 ${
            selectedFilter === "dibawah_5rb"
              ? "bg-emerald-600 text-white border-emerald-600"
              : "bg-white text-gray-700 border-gray-200 hover:border-gray-400"
          }`}
        >
          <span>Dibawah 5rb 🛵</span>
          {selectedFilter === "dibawah_5rb" && <Check className="h-3 w-3 inline" />}
        </button>

        <button
          onClick={() => setSelectedFilter(selectedFilter === "menu_30rb" ? null : "menu_30rb")}
          className={`px-4 py-2 rounded-full border text-xs font-bold transition-all shrink-0 flex items-center space-x-1.5 ${
            selectedFilter === "menu_30rb"
              ? "bg-emerald-600 text-white border-emerald-600"
              : "bg-white text-gray-700 border-gray-200 hover:border-gray-400"
          }`}
        >
          <span>Menu 30rb 🍜</span>
          {selectedFilter === "menu_30rb" && <Check className="h-3 w-3 inline" />}
        </button>

        <button
          onClick={() => setSelectedFilter(selectedFilter === "diskon_40" ? null : "diskon_40")}
          className={`px-4 py-2 rounded-full border text-xs font-bold transition-all shrink-0 flex items-center space-x-1.5 ${
            selectedFilter === "diskon_40"
              ? "bg-emerald-600 text-white border-emerald-600"
              : "bg-white text-gray-700 border-gray-200 hover:border-gray-400"
          }`}
        >
          <span>Pasti Promo 🏷️</span>
          {selectedFilter === "diskon_40" && <Check className="h-3 w-3 inline" />}
        </button>

        <button
          onClick={() => setSelectedFilter(selectedFilter === "rating_high" ? null : "rating_high")}
          className={`px-4 py-2 rounded-full border text-xs font-bold transition-all shrink-0 flex items-center space-x-1.5 ${
            selectedFilter === "rating_high"
              ? "bg-emerald-600 text-white border-emerald-600"
              : "bg-white text-gray-700 border-gray-200 hover:border-gray-400"
          }`}
        >
          <span>Rating 4.9+ ⭐</span>
          {selectedFilter === "rating_high" && <Check className="h-3 w-3 inline" />}
        </button>
      </div>

      {/* RESTAURANT LIST CARDS WITH PHOTOS */}
      <div className="space-y-4 max-w-2xl text-left">
        {filteredList.map((resto) => {
          const primaryBranch = resto.branches[0];
          const originalDeliveryCost = "15.5rb";
          const isCheapDelivery = primaryBranch.deliveryFee <= 4000;
          const displayDeliveryText = isCheapDelivery 
            ? `Ongkir ${(primaryBranch.deliveryFee / 1000).toFixed(0)}rb` 
            : `Ongkir ${(primaryBranch.deliveryFee / 1000).toFixed(0)}rb`;

          return (
            <div
              key={resto.id}
              onClick={() => onSelectRestaurant(resto, primaryBranch)}
              className="bg-white border border-gray-150 rounded-3xl p-4 sm:p-5 flex gap-4 hover:shadow-lg hover:border-emerald-500 transition-all cursor-pointer group"
              id={`category-item-card-${resto.id}`}
            >
              {/* Photo of the restaurant food - left column */}
              <div className="h-24 w-24 sm:h-28 sm:w-28 rounded-2xl overflow-hidden shrink-0 bg-gray-100 border border-gray-100">
                <SafeImage
                  type="banner"
                  src={resto.bannerImage}
                  alt={resto.brandName}
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>

              {/* Restaurant Info - right column */}
              <div className="flex-1 min-w-0 space-y-1.5 flex flex-col justify-between">
                <div>
                  <h4 className="font-extrabold text-sm sm:text-base text-gray-950 truncate group-hover:text-emerald-700 transition-colors">
                    {resto.brandName}
                  </h4>
                  
                  {/* Rating + Distance segment */}
                  <div className="flex flex-wrap items-center gap-x-2 text-[11px] sm:text-xs text-gray-500 mt-1">
                    <span className="flex items-center font-bold text-amber-500">
                      <Star className="h-3 w-3 fill-amber-500 inline mr-0.5" />
                      <span>{resto.rating}</span>
                    </span>
                    <span>({primaryBranch.ratingCount})</span>
                    <span>•</span>
                    <span className="font-semibold text-gray-700">Rp15rb-Rp50rb</span>
                    <span>•</span>
                    <span className="truncate">{resto.categoryTags.slice(0, 3).join(", ")}</span>
                  </div>

                  {/* Delivery Info */}
                  <div className="flex items-center space-x-3 text-[11px] sm:text-xs mt-2">
                    <div className="flex items-center text-emerald-700 font-extrabold space-x-1 bg-emerald-50 px-2 py-0.5 rounded-sm shrink-0 border border-emerald-100">
                      <span className="text-[10px]">✔</span>
                      <span>{displayDeliveryText}</span>
                    </div>
                    {isCheapDelivery && (
                      <span className="text-gray-450 text-[10px] sm:text-xs line-through">{originalDeliveryCost}</span>
                    )}
                    <div className="flex items-center text-red-500 font-extrabold shrink-0 bg-red-50 px-2 py-0.5 rounded-sm border border-red-100">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>{primaryBranch.avgDeliveryTime === "15 min" ? "⚡ 15 min" : primaryBranch.avgDeliveryTime}</span>
                    </div>
                  </div>
                </div>

                {/* Promos */}
                <div className="flex flex-wrap gap-1.5 pt-1.5">
                  {primaryBranch.promos.slice(0, 2).map((promo, idx) => (
                    <div
                      key={idx}
                      className="inline-flex items-center space-x-1.5 border border-dashed border-red-200 bg-red-25/50 px-2.5 py-1 rounded-full text-[10px] sm:text-[11px] font-black text-red-700"
                    >
                      <BadgePercent className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate max-w-[150px] sm:max-w-[220px]">{promo}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}

        {filteredList.length === 0 && (
          <div className="py-12 text-center bg-white border border-gray-200 rounded-3xl">
            <p className="text-sm text-gray-500">Tidak ada restoran yang cocok dengan kriteria filter.</p>
            <button
              onClick={() => setSelectedFilter(null)}
              className="mt-3 text-xs font-bold text-emerald-600 hover:underline"
            >
              Reset Filter
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
