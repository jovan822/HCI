import { X, MapPin, Star, Sparkles, Navigation, BadgePercent } from "lucide-react";
import { Restaurant, Branch } from "../types";
import SafeImage from "./SafeImage";

interface BranchGroupModalProps {
  restaurant: Restaurant | null;
  onClose: () => void;
  onSelectBranch: (restaurant: Restaurant, branch: Branch) => void;
}

export default function BranchGroupModal({ restaurant, onClose, onSelectBranch }: BranchGroupModalProps) {
  if (!restaurant) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      {/* Background click listener */}
      <div className="absolute inset-0" onClick={onClose}></div>

      {/* Sheet Content */}
      <div 
        className="relative bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] sm:max-h-[80vh] animate-in slide-in-from-bottom duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header decoration */}
        <div className="relative h-32 sm:h-36 shrink-0">
          <SafeImage
            type="banner"
            src={restaurant.bannerImage}
            alt={restaurant.brandName}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-all cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="absolute bottom-4 left-4 right-4 flex items-center space-x-3">
            <SafeImage
              type="logo"
              src={restaurant.logo}
              alt={restaurant.brandName}
              className="h-14 w-14 rounded-2xl object-cover bg-white p-1 shadow-md shrink-0"
            />
            <div>
              <span className="bg-emerald-600 text-white font-extrabold text-[10px] uppercase px-2 py-0.5 rounded-full tracking-wider">
                Grouped Brand
              </span>
              <h3 className="text-xl font-bold text-white mt-1 flex items-center">
                {restaurant.brandName}
                {restaurant.isHalal && (
                  <span className="ml-2 bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 font-semibold text-[9px] px-1.5 py-0.5 rounded-md uppercase">
                    Halal
                  </span>
                )}
              </h3>
            </div>
          </div>
        </div>

        {/* Brand overview info */}
        <div className="p-4 bg-emerald-50/60 border-b border-emerald-100 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center space-x-1.5 text-gray-700">
            <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
            <span className="font-bold text-sm text-gray-900">{restaurant.rating}</span>
            <span className="text-gray-500">•</span>
            <span>{restaurant.categoryTags.join(", ")}</span>
          </div>
          <span className="text-emerald-700 font-medium">Ada {restaurant.branches.length} cabang terdekat</span>
        </div>

        {/* Branch List */}
        <div className="p-4 overflow-y-auto space-y-3 bg-gray-50 flex-1">
          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center space-x-1">
            <Navigation className="h-3.5 w-3.5 text-emerald-600" />
            <span>PILIH CABANG COCOK UNTUK KAMU</span>
          </h4>

          {restaurant.branches.map((branch) => (
            <button
              key={branch.id}
              onClick={() => onSelectBranch(restaurant, branch)}
              className="w-full text-left bg-white p-4 rounded-2xl hover:border-emerald-500 hover:ring-2 hover:ring-emerald-500/10 border border-gray-100 transition-all flex justify-between items-start group shadow-xs cursor-pointer"
            >
              <div className="flex-1 min-w-0 pr-3">
                <div className="flex items-center space-x-1.5">
                  <h5 className="font-bold text-gray-900 group-hover:text-emerald-700 transition-colors text-sm sm:text-base">
                    {restaurant.brandName} - {branch.name}
                  </h5>
                  {branch.id.includes("kemanggisan") && (
                    <span className="bg-orange-100 text-orange-850 font-bold text-[9px] px-1.5 py-0.5 rounded-md shrink-0">
                      Terdekat
                    </span>
                  )}
                </div>
                
                <p className="text-xs text-gray-550 truncate mt-1.5 flex items-center">
                  <MapPin className="h-3 w-3 text-gray-400 mr-1 shrink-0" />
                  {branch.address}
                </p>

                {/* Badges row */}
                <div className="flex flex-wrap gap-2 mt-3 p-1.5 bg-gray-50 rounded-xl">
                  <div className="flex items-center text-[10px] text-gray-600 font-medium">
                    <Star className="h-3 w-3 text-amber-500 mr-0.5 fill-amber-500" />
                    <strong>{branch.rating}</strong>
                    <span className="text-gray-400 ml-1">({branch.ratingCount})</span>
                  </div>
                  <span className="text-gray-300">•</span>
                  <div className="text-[10px] text-emerald-600 font-semibold">
                    Ongkir {(branch.deliveryFee / 1000).toFixed(1)}rb
                    {branch.deliveryFeeOriginal && (
                      <span className="text-gray-400 line-through ml-1 font-normal">
                        {(branch.deliveryFeeOriginal / 1000).toFixed(1)}rb
                      </span>
                    )}
                  </div>
                  <span className="text-gray-300">•</span>
                  <div className="text-[10px] text-gray-600">
                    Est. <strong>{branch.avgDeliveryTime}</strong>
                  </div>
                </div>

                {/* Promos */}
                {branch.promos.length > 0 && (
                  <div className="flex items-center space-x-1 mt-2.5">
                    <BadgePercent className="h-4 w-4 text-red-500" />
                    <span className="text-[11px] font-bold text-red-600 truncate">
                      {branch.promos.join(" & ")}
                    </span>
                  </div>
                )}
              </div>

              {/* Selection Arrow / Indicator */}
              <div className="self-center bg-gray-50 group-hover:bg-emerald-600 group-hover:text-white text-gray-400 p-2 rounded-xl transition-all shadow-2xs shrink-0">
                <span className="text-xs font-bold px-1 py-0.5 block">Pesan</span>
              </div>
            </button>
          ))}
        </div>

        {/* Footer info banner */}
        <div className="p-4 bg-white border-t border-gray-100 flex items-center justify-between text-xs shrink-0">
          <span className="text-gray-500">Harga bergaransi paling kompetitif</span>
          <div className="flex items-center space-x-1 font-semibold text-emerald-600">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Pesan Instan Terlindungi</span>
          </div>
        </div>
      </div>
    </div>
  );
}
