import { useState, useEffect } from "react";
import { 
  ArrowLeft, Star, Heart, Share2, Search, BadgePercent, Clock, MapPin, 
  Plus, Minus, X, AlertCircle, ShoppingBag, CheckCircle2 
} from "lucide-react";
import { Restaurant, Branch, MenuItem, CartItem } from "../types";
import SafeImage from "./SafeImage";

interface RestaurantDetailViewProps {
  restaurant: Restaurant;
  selectedBranch: Branch;
  onBack: () => void;
  onAddToCart: (item: MenuItem, quantity: number, notes: string, customizations: { [optionName: string]: string }) => void;
}

export default function RestaurantDetailView({
  restaurant,
  selectedBranch,
  onBack,
  onAddToCart,
}: RestaurantDetailViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Semua");
  const [deliveryType, setDeliveryType] = useState<"delivery" | "pickup">("delivery");
  const [isFavorite, setIsFavorite] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  // Customization modal state
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [customizations, setCustomizations] = useState<{ [optionName: string]: string }>({});
  const [itemQuantity, setItemQuantity] = useState(1);
  const [itemNotes, setItemNotes] = useState("");

  // Flash Sale Countdown Setup
  const [timeLeft, setTimeLeft] = useState({ hours: 1, minutes: 30, seconds: 15 });
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          clearInterval(timer);
          return prev;
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = () => {
    const h = String(timeLeft.hours).padStart(2, "0");
    const m = String(timeLeft.minutes).padStart(2, "0");
    const s = String(timeLeft.seconds).padStart(2, "0");
    return `${h} : ${m} : ${s}`;
  };

  // Extract menu categories
  const categories = ["Semua", ...Array.from(new Set(restaurant.menu.map((m) => m.category)))];

  // Filter menu items
  const filteredMenu = restaurant.menu.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "Semua" || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Open item customization selection
  const handleOpenCustomizer = (item: MenuItem) => {
    const defaultCusts: { [optName: string]: string } = {};
    if (item.customizationOptions) {
      item.customizationOptions.forEach((option) => {
        defaultCusts[option.name] = option.choices[0];
      });
    }
    setCustomizations(defaultCusts);
    setItemQuantity(1);
    setItemNotes("");
    setCustomizingItem(item);
  };

  const handleAddWithCustomizations = () => {
    if (!customizingItem) return;
    onAddToCart(customizingItem, itemQuantity, itemNotes, customizations);
    
    // Trigger success toast
    setToastMessage(`Tambahkan: ${itemQuantity}x ${customizingItem.name}`);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2500);

    setCustomizingItem(null);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString("id-ID");
  };

  return (
    <div className="relative pb-24">
      {/* Toast Alert */}
      {showToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-gray-900 text-white font-semibold text-xs sm:text-sm px-5 py-3 rounded-xl shadow-2xl flex items-center space-x-2 animate-in fade-in duration-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hero Banner Grid layout */}
      <div className="relative h-48 md:h-64">
        <SafeImage
          type="banner"
          src={restaurant.bannerImage}
          alt={restaurant.brandName}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900/90 via-gray-900/30 to-black/40"></div>

        {/* Back and Action Buttons */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="bg-white/90 text-gray-800 p-2.5 rounded-full hover:bg-white transition-all shadow-md flex items-center justify-center cursor-pointer"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          <div className="flex space-x-2">
            <button
              onClick={() => setIsFavorite(!isFavorite)}
              className="bg-white/90 p-2.5 rounded-full hover:bg-white transition-all shadow-md flex items-center justify-center cursor-pointer"
            >
              <Heart className={`h-5 w-5 ${isFavorite ? "text-red-500 fill-red-500" : "text-gray-600"}`} />
            </button>
            <button className="bg-white/90 p-2.5 rounded-full hover:bg-white transition-all shadow-md flex items-center justify-center">
              <Share2 className="h-5 w-5 text-gray-600" />
            </button>
          </div>
        </div>
      </div>

      {/* Floating Header Card */}
      <div className="max-w-4xl mx-auto px-4 -mt-16 relative z-10">
        <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xl border border-gray-100">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3.5">
              <SafeImage
                type="logo"
                src={restaurant.logo}
                alt={restaurant.brandName}
                className="h-16 w-16 sm:h-20 sm:w-20 rounded-2xl object-cover border border-gray-150 p-1 shadow-sm shrink-0 bg-white"
              />
              <div>
                <div className="flex items-center space-x-2">
                  <span className="bg-emerald-600 text-white font-extrabold text-[10px] px-2 py-0.5 rounded-md tracking-wider">
                    PLUS MEMBER
                  </span>
                  {restaurant.isHalal && (
                    <span className="bg-orange-50 text-orange-700 border border-orange-200/50 font-bold text-[9px] px-1.5 py-0.5 rounded-sm uppercase tracking-wide">
                      HALAL INDONESIA
                    </span>
                  )}
                </div>
                <h1 className="text-xl sm:text-2xl font-black text-gray-900 mt-1">
                  {restaurant.brandName}, {selectedBranch.name}
                </h1>
                <p className="text-xs sm:text-sm text-gray-500 font-medium mt-1">
                  {restaurant.categoryTags.join(" • ")}
                </p>
              </div>
            </div>

            {/* Rating side badge */}
            <div className="bg-amber-50 text-amber-900 p-2 rounded-2xl border border-amber-100 flex flex-col items-center justify-center shrink-0 min-w-14">
              <div className="flex items-center space-x-1">
                <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                <span className="font-extrabold text-sm">{restaurant.rating}</span>
              </div>
              <span className="text-[10px] text-amber-700 font-semibold mt-0.5">{selectedBranch.ratingCount}</span>
            </div>
          </div>

          <p className="text-xs text-gray-400 mt-3 flex items-center">
            <MapPin className="h-3.5 w-3.5 text-gray-300 mr-1 shrinkage-0" />
            {selectedBranch.address}
          </p>

          <hr className="my-4 border-gray-100" />

          {/* Delivery vs Pickup Selector Segment */}
          <div className="grid grid-cols-2 gap-2 bg-gray-50 p-1.5 rounded-2xl max-w-sm mx-auto sm:mx-0">
            <button
              onClick={() => setDeliveryType("delivery")}
              className={`py-2 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center space-x-1.5 ${
                deliveryType === "delivery"
                  ? "bg-emerald-600 text-white shadow-xs"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <span>Antar Delivery</span>
            </button>
            <button
              onClick={() => setDeliveryType("pickup")}
              className={`py-2 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center space-x-1.5 ${
                deliveryType === "pickup"
                  ? "bg-emerald-600 text-white shadow-xs"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <span>Ambil Sendiri (Pickup)</span>
            </button>
          </div>

          {/* Logistics dynamic row */}
          <div className="flex flex-wrap items-center justify-between gap-4 mt-4 pt-1 text-xs">
            <div className="flex items-center space-x-6 text-gray-700 font-medium">
              <div className="flex items-center space-x-1.5">
                <Clock className="h-4 w-4 text-gray-400" />
                <span>ETA: <strong className="text-gray-900">{selectedBranch.avgDeliveryTime}</strong> ({selectedBranch.distance} km)</span>
              </div>
              <span className="text-gray-300 hidden sm:inline">|</span>
              <div className="text-emerald-700 font-bold">
                Biaya Ongkir: Rp {formatPrice(selectedBranch.deliveryFee)}
                {selectedBranch.deliveryFeeOriginal && (
                  <span className="text-gray-400 line-through font-normal ml-1">
                    Rp {formatPrice(selectedBranch.deliveryFeeOriginal)}
                  </span>
                )}
              </div>
            </div>

            <span className="bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full font-bold text-[10px] uppercase tracking-wide">
              ⚡ Jaminan 15 Menit Antar
            </span>
          </div>
        </div>

        {/* Promo Code vouchers carousels */}
        {selectedBranch.promos.length > 0 && (
          <div className="mt-4 flex gap-3 overflow-x-auto pb-2 scrollbar-none">
            {selectedBranch.promos.map((promo, idx) => (
              <div 
                key={idx} 
                className="bg-emerald-500 text-white px-4 py-2.5 rounded-2xl text-[11px] font-bold flex items-center space-x-2 whitespace-nowrap shadow-xs"
              >
                <BadgePercent className="h-4 w-4 text-emerald-100" />
                <span>{promo}</span>
              </div>
            ))}
            <div className="bg-amber-500 text-white px-4 py-2.5 rounded-2xl text-[11px] font-bold flex items-center space-x-2 whitespace-nowrap shadow-xs">
              <BadgePercent className="h-4 w-4 text-amber-100" />
              <span>Gunakan Voucher & Hemat Tambahan s.d 50%</span>
            </div>
          </div>
        )}

        {/* Search Inside Menu */}
        <div className="mt-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Cari makanan favoritmu di resto ini..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all"
            />
          </div>

          {/* Quick Menu Category Pill Filters */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none max-w-full">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? "bg-gray-900 text-white"
                    : "bg-gray-50 hover:bg-gray-100 text-gray-700"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Flash Sale Section (If contains) */}
        {restaurant.menu.some((x) => x.isFlashSale) && (
          <div className="mt-8 bg-red-50 border border-red-150 rounded-3xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <span className="text-xl">⚡</span>
                <h3 className="font-black text-red-900 text-base sm:text-lg">Flash Sale Terbatas, Buruan Jajan!</h3>
              </div>
              <div className="bg-red-600 text-white font-mono font-black text-xs px-3 py-1.5 rounded-xl flex items-center space-x-1 shadow-inner">
                <span>⏱️</span>
                <span>{formatCountdown()}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {restaurant.menu
                .filter((x) => x.isFlashSale)
                .map((item) => (
                  <div 
                    key={item.id} 
                    onClick={() => handleOpenCustomizer(item)}
                    className="bg-white p-4 rounded-2xl border border-red-100 hover:border-red-400 transition-all cursor-pointer flex justify-between gap-3 shadow-xs hover:shadow-md"
                  >
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        {item.tags && (
                          <div className="flex flex-wrap gap-1 mb-1">
                            {item.tags.map((t, idx) => (
                              <span key={idx} className="bg-red-50 text-red-700 text-[9px] font-black uppercase px-1 rounded-sm">
                                {t}
                              </span>
                            ))}
                          </div>
                        )}
                        <h4 className="font-bold text-gray-950 text-sm sm:text-base truncate">{item.name}</h4>
                        <p className="text-[11px] text-gray-500 line-clamp-2 mt-1 leading-normal">{item.description}</p>
                      </div>
                      
                      <div className="mt-3">
                        <div className="flex items-baseline space-x-1.5">
                          <span className="font-extrabold text-red-600 text-sm sm:text-base">Rp {formatPrice(item.price)}</span>
                          {item.originalPrice && (
                            <span className="text-xs text-gray-400 line-through">Rp {formatPrice(item.originalPrice)}</span>
                          )}
                          <span className="bg-red-100 text-red-700 text-[10px] font-bold px-1.5 py-0.2 rounded-md">
                            -{item.discountPercentage}%
                          </span>
                        </div>
                        <span className="text-[10px] text-red-500 font-bold block mt-1">⭐️ 4.9 (200+) • Flash Sale</span>
                      </div>
                    </div>
                    {item.image && (
                      <div className="h-20 w-20 sm:h-24 sm:w-24 rounded-2xl overflow-hidden shrink-0 bg-gray-100 relative">
                        <SafeImage type="food" src={item.image} alt={item.name} className="h-full w-full object-cover" />
                        <div className="absolute bottom-2 right-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-2.5 py-1 rounded-full shadow-lg">
                          Tambah
                        </div>
                      </div>
                    )}
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Regular Menu Section */}
        <div className="mt-8 space-y-6">
          {categories.filter(c => c !== "Semua").map((category) => {
            const categoryItems = filteredMenu.filter((x) => x.category === category);
            if (categoryItems.length === 0) return null;

            return (
              <div key={category} className="space-y-3">
                <h3 className="font-extrabold text-gray-900 border-l-4 border-emerald-600 pl-2.5 text-base sm:text-lg uppercase tracking-wide">
                  {category}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {categoryItems.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => handleOpenCustomizer(item)}
                      className="bg-white p-4 rounded-2xl border border-gray-100 hover:border-emerald-500 hover:shadow-md transition-all cursor-pointer flex justify-between gap-3 shadow-xs relative"
                    >
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <div>
                          {item.isPopular && (
                            <span className="bg-amber-500 text-white font-extrabold text-[8px] uppercase px-1.5 py-0.5 rounded-md tracking-wider mr-2">
                              Populer
                            </span>
                          )}
                          <h4 className="font-bold text-gray-900 text-sm sm:text-base mt-1">{item.name}</h4>
                          <p className="text-xs text-gray-500 line-clamp-2 mt-1 leading-relaxed">
                            {item.description}
                          </p>
                        </div>

                        <div className="mt-3 flex items-center space-x-2">
                          <span className="font-extrabold text-gray-950 text-sm sm:text-base">
                            Rp {formatPrice(item.price)}
                          </span>
                          {item.originalPrice && (
                            <span className="text-xs text-gray-400 line-through">
                              Rp {formatPrice(item.originalPrice)}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="relative h-20 w-20 sm:h-24 sm:w-24 rounded-2xl overflow-hidden shrink-0 bg-gray-100 border border-gray-100 self-center">
                        <SafeImage type="food" src={item.image} alt={item.name} className="h-full w-full object-cover" />
                        <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 bg-white text-emerald-600 border border-emerald-100 font-extrabold text-[11px] px-3 py-1 rounded-full shadow-md hover:bg-emerald-50 whitespace-nowrap">
                          Tambah
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {filteredMenu.length === 0 && (
            <div className="p-8 text-center bg-gray-50 rounded-2xl border border-dashed border-gray-250">
              <AlertCircle className="h-8 w-8 text-gray-400 mx-auto" />
              <p className="text-xs sm:text-sm text-gray-500 font-medium mt-2">Menu tidak ditemukan. Coba pencarian lain.</p>
            </div>
          )}
        </div>
      </div>

      {/* Item Customization Modal Overlay */}
      {customizingItem && (
        <div className="fixed inset-0 z-55 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0" onClick={() => setCustomizingItem(null)}></div>

          <div className="relative bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl p-6 overflow-hidden flex flex-col max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-gray-100">
              <div>
                <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black uppercase px-2 py-0.5 rounded-sm">
                  Sesuaikan Pesanan
                </span>
                <h3 className="text-lg font-black text-gray-900 mt-1">{customizingItem.name}</h3>
                <p className="font-extrabold text-emerald-600 mt-0.5 text-base">
                  Rp {formatPrice(customizingItem.price)}
                </p>
              </div>
              <button 
                onClick={() => setCustomizingItem(null)}
                className="text-gray-400 hover:text-gray-600 bg-gray-50 p-1.5 rounded-full"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content Customization Section */}
            <div className="overflow-y-auto py-4 space-y-5 flex-1 max-h-[50vh] scrollbar-thin">
              <div className="flex items-center space-x-3 bg-gray-50 p-3 rounded-2xl">
                <SafeImage type="food" src={customizingItem.image} alt={customizingItem.name} className="h-14 w-14 rounded-xl object-cover shrink-0" />
                <p className="text-xs text-gray-500 leading-normal">{customizingItem.description}</p>
              </div>

              {/* Dynamic Option Checks */}
              {customizingItem.customizationOptions?.map((option) => (
                <div key={option.name} className="space-y-2 border-b border-gray-50 pb-4">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-gray-900 text-sm sm:text-base capitalize">{option.name}</span>
                    {option.required ? (
                      <span className="bg-red-55/60 text-red-700 text-[9px] font-extrabold px-1.5 py-0.5 rounded-md">Wajib</span>
                    ) : (
                      <span className="bg-gray-100 text-gray-500 text-[9px] font-bold px-1.5 py-0.5 rounded-md">Opsional</span>
                    )}
                  </div>
                  <div className="space-y-1.5">
                    {option.choices.map((choice) => (
                      <label 
                        key={choice} 
                        className="flex items-center justify-between p-2.5 rounded-xl border border-gray-100 hover:bg-emerald-50/20 hover:border-emerald-250 cursor-pointer transition-all text-xs sm:text-sm"
                      >
                        <span className="text-gray-700 font-medium">{choice}</span>
                        <input
                          type="radio"
                          name={option.name}
                          checked={customizations[option.name] === choice}
                          onChange={() => setCustomizations({ ...customizations, [option.name]: choice })}
                          className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-350"
                        />
                      </label>
                    ))}
                  </div>
                </div>
              ))}

              {/* Driver and Resto Notes */}
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-800">
                  Catatan Khusus <span className="text-gray-400 font-normal">(opsional)</span>
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Setengah Mateng, No Spicy, Sambal Dipisah..."
                  value={itemNotes}
                  onChange={(e) => setItemNotes(e.target.value)}
                  className="w-full p-2.5 border border-gray-200 rounded-xl bg-gray-50 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all"
                />
                <p className="text-[10px] text-gray-450">Bisa notes permintaan rasa, bumbu dipisah, atau kematangan.</p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
              {/* Quantity Changer */}
              <div className="flex items-center space-x-3.5 bg-gray-100 p-1.5 rounded-2xl">
                <button 
                  onClick={() => setItemQuantity(Math.max(1, itemQuantity - 1))}
                  className="p-1.5 bg-white text-gray-700 rounded-xl hover:bg-emerald-50 hover:text-emerald-600 transition-all border border-gray-150 shadow-2xs"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="font-black text-gray-950 text-base min-w-4 text-center">{itemQuantity}</span>
                <button 
                  onClick={() => setItemQuantity(itemQuantity + 1)}
                  className="p-1.5 bg-white text-gray-700 rounded-xl hover:bg-emerald-50 hover:text-emerald-600 transition-all border border-gray-150 shadow-2xs"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              {/* Action Button */}
              <button
                onClick={handleAddWithCustomizations}
                className="flex-1 ml-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3 px-4 rounded-2xl shadow-lg shadow-emerald-600/20 text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer"
              >
                <ShoppingBag className="h-4 w-4" />
                <span>Tambah ke Keranjang</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
