import { useState } from "react";
import { 
  X, Trash2, Plus, Minus, ReceiptText, BadgePercent, MapPin, 
  Sparkles, CreditCard, ShoppingBag, ArrowRight, Clipboard, ChevronRight, Image as ImageIcon, ArrowLeft
} from "lucide-react";
import { CartItem, LocationProfile, OrderInvoice, MenuItem } from "../types";
import SafeImage from "./SafeImage";

interface CheckoutInvoicePanelProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateCartItemQuantity: (branchId: string, id: string, quantity: number) => void;
  onRemoveCartItem: (branchId: string, id: string) => void;
  currentLocation: LocationProfile;
  onCheckout: (invoice: OrderInvoice, driverNote: string, checkoutItems?: CartItem[]) => void;
}

// Preloaded realistic draft restaurants from user's screenshot
interface PreloadedDraft {
  branchId: string;
  restaurantId: string;
  restaurantName: string;
  branchName: string;
  logo: string;
  promos: string[];
  distance: string;
  avgDeliveryTime: string;
  defaultItems: { menuItem: MenuItem; quantity: number; notes: string }[];
}

const PRELOADED_DRAFTS: PreloadedDraft[] = [
  {
    branchId: "sec-bowl-kemanggisan",
    restaurantId: "sec-bowl",
    restaurantName: "Sec Bowl",
    branchName: "Kemanggisan",
    logo: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=200&auto=format&fit=crop&q=80",
    promos: ["Diskon makanan 31% s.d. 49rb", "Gratis Ongkir min. 40rb"],
    distance: "1,4 km",
    avgDeliveryTime: "Mulai dari 15-25 menit",
    defaultItems: [
      {
        menuItem: {
          id: "sec-m1",
          name: "Salted Egg Chicken Box",
          price: 58500,
          description: "Ayam goreng renyah disiram saus telur asin khas Sec Bowl yang gurih, creamy, dan nikmat, disajikan dengan nasi hangat dan telur mata sapi setengah matang.",
          image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?w=150",
          category: "Best Seller 🌟"
        },
        quantity: 1,
        notes: "Kematangan Telur: Setengah Mateng, Tingkat Kepedasan: Spicy"
      }
    ]
  },
  {
    branchId: "kfc-s-parman",
    restaurantId: "kfc",
    restaurantName: "KFC",
    branchName: "S Parman",
    logo: "https://images.unsplash.com/photo-1513639773648-2b98865be901?w=200&auto=format&fit=crop&q=80",
    promos: ["Diskon Rp30.000", "Gratis Ongkir Rp6.000"],
    distance: "1,1 km",
    avgDeliveryTime: "Mulai dari 15-25 menit",
    defaultItems: [
      {
        menuItem: {
          id: "kfc-m1",
          name: "Paket Super Besar 1",
          price: 38500,
          description: "1 Pcs Crispy/O.R. Chicken + 1 Nasi + 1 Coca Cola Medium.",
          image: "https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?w=150",
          category: "Promo Special 🍗"
        },
        quantity: 2,
        notes: "Pilihan Ayam: Crispy, Pilihan Potongan: Dada"
      }
    ]
  },
  {
    branchId: "fore-kemanggisan-branch",
    restaurantId: "fore-coffee",
    restaurantName: "Fore Coffee (Kopi)",
    branchName: "OCBC NISP Kemanggisan",
    logo: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=200&auto=format&fit=crop&q=80",
    promos: ["Diskon 25%", "Hemat Ongkir Rp10.000"],
    distance: "1,5 km",
    avgDeliveryTime: "Mulai dari 15-20 menit",
    defaultItems: [
      {
        menuItem: {
          id: "fore-m1",
          name: "Iced Bumi Latte",
          price: 32000,
          description: "Espresso spesial dikombinasikan dengan susu segar premium dan sirup gula aren alami khas Fore.",
          image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=150",
          category: "Best Seller ☕"
        },
        quantity: 1,
        notes: "Jenis Susu: Oatmilk, Takaran Manis: Less Sweet"
      }
    ]
  },
  {
    branchId: "jco-slipi-branch-1",
    restaurantId: "jco-slipi",
    restaurantName: "JCO",
    branchName: "Slipi Jaya",
    logo: "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=200&auto=format&fit=crop&q=80",
    promos: ["Hemat Rp35.800", "Ongkir Murah 5rb"],
    distance: "1,7 km",
    avgDeliveryTime: "Mulai dari 15-25 menit",
    defaultItems: [
      {
        menuItem: {
          id: "jco-m1",
          name: "Donuts 1 Dzn",
          price: 88000,
          description: "Pilihan 12 pcs donat artisan aneka rasa favorit Anda (Alcapone, Oreology, Avocado Dicaprio, dll).",
          image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=150",
          category: "Sharing Pack"
        },
        quantity: 1,
        notes: "Rasa Alcapone & Avocado Dicaprio"
      }
    ]
  }
];

export default function CheckoutInvoicePanel({
  isOpen,
  onClose,
  cart,
  onUpdateCartItemQuantity,
  onRemoveCartItem,
  currentLocation,
  onCheckout,
}: CheckoutInvoicePanelProps) {
  // Navigation: null shows list of drafts ("Daftar Pesanan Saya"). A branchId shows the checkout view.
  const [selectedBranchId, setSelectedBranchId] = useState<string | null>(null);

  // Form local states for checkout details
  const [driverNote, setDriverNote] = useState("Bertemu di depan pintu.");
  const [paymentMethod, setPaymentMethod] = useState<"gopay" | "ovo" | "cc">("gopay");
  const [promoApplied, setPromoApplied] = useState<"none" | "promo50" | "ongkir10">("promo50");

  // Keep track of preloaded draft items in a local map so editing them works beautifully!
  const [draftItemsMap, setDraftItemsMap] = useState<{ [branchId: string]: CartItem[] }>(() => {
    const initialMap: { [branchId: string]: CartItem[] } = {};
    PRELOADED_DRAFTS.forEach(draft => {
      initialMap[draft.branchId] = draft.defaultItems.map(di => ({
        menuItem: di.menuItem,
        restaurantId: draft.restaurantId,
        restaurantName: draft.restaurantName,
        branchId: draft.branchId,
        branchName: draft.branchName,
        quantity: di.quantity,
        notes: di.notes,
        selectedCustomizations: {}
      }));
    });
    return initialMap;
  });

  if (!isOpen) return null;

  // --- Dynamic Grouping & Drafting Engine ---
  // Collect all branches that currently have items.
  // 1. Live entries from the global React cart:
  const userBranchesMap: { [branchId: string]: CartItem[] } = {};
  cart.forEach((item) => {
    if (!userBranchesMap[item.branchId]) {
      userBranchesMap[item.branchId] = [];
    }
    userBranchesMap[item.branchId].push(item);
  });

  // Get full lists of drafts unified together (either actual user cart or preloaded screenshot mock drafts)
  const allDraftsList = [...PRELOADED_DRAFTS];
  
  // If the user has added items from a restaurant NOT in PRELOADED_DRAFTS, we prepend/append it!
  Object.keys(userBranchesMap).forEach((bId) => {
    const alreadyListed = allDraftsList.some(d => d.branchId === bId);
    if (!alreadyListed && userBranchesMap[bId].length > 0) {
      const firstItem = userBranchesMap[bId][0];
      allDraftsList.unshift({
        branchId: bId,
        restaurantId: firstItem.restaurantId,
        restaurantName: firstItem.restaurantName,
        branchName: firstItem.branchName,
        logo: firstItem.menuItem.image || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=150",
        promos: ["Diskon 50%", "Paling Hemat 👍"],
        distance: "1,2 km",
        avgDeliveryTime: "Mulai dari 15 menit",
        defaultItems: [] // unused since it lives in userBranchesMap
      });
    }
  });

  // Function to pull items for a specific branch
  const getBranchItems = (branchId: string): CartItem[] => {
    if (userBranchesMap[branchId] && userBranchesMap[branchId].length > 0) {
      return userBranchesMap[branchId];
    }
    return draftItemsMap[branchId] || [];
  };

  // --- Quantity & Item Handlers inside Checkout ---
  const handleUpdateItemQty = (branchId: string, itemId: string, newQty: number) => {
    const isGlobal = cart.some(x => x.branchId === branchId && x.menuItem.id === itemId);
    if (isGlobal) {
      onUpdateCartItemQuantity(branchId, itemId, newQty);
    } else {
      setDraftItemsMap(prev => {
        const list = prev[branchId] || [];
        const updated = list.map(x => x.menuItem.id === itemId ? { ...x, quantity: newQty } : x);
        return { ...prev, [branchId]: updated };
      });
    }
  };

  const handleRemoveItem = (branchId: string, itemId: string) => {
    const isGlobal = cart.some(x => x.branchId === branchId && x.menuItem.id === itemId);
    if (isGlobal) {
      onRemoveCartItem(branchId, itemId);
    } else {
      setDraftItemsMap(prev => {
        const list = prev[branchId] || [];
        const updated = list.filter(x => x.menuItem.id !== itemId);
        return { ...prev, [branchId]: updated };
      });
    }
  };

  // --- Calculations for Checkout Details View ---
  let activeBranchObj = allDraftsList.find(d => d.branchId === selectedBranchId);
  const checkoutItems = selectedBranchId ? getBranchItems(selectedBranchId) : [];
  
  const subtotal = checkoutItems.reduce((acc, item) => acc + item.menuItem.price * item.quantity, 0);
  const deliveryFee = checkoutItems.length > 0 ? 9500 : 0;
  const restaurantServiceFee = checkoutItems.length > 0 ? 3000 : 0;
  const platformFee = checkoutItems.length > 0 ? 1000 : 0;

  let deliveryDiscount = 0;
  let promoDiscount = 0;

  if (checkoutItems.length > 0) {
    if (promoApplied === "promo50" || promoApplied === "ongkir10") {
      deliveryDiscount = -9500; // Free delivery representation
    }
    if (promoApplied === "promo50") {
      promoDiscount = Math.round(subtotal * 0.4); // 40% discount on food
    }
  }

  const grandTotal = Math.max(0, subtotal + deliveryFee + restaurantServiceFee + platformFee + deliveryDiscount - promoDiscount);

  const invoice: OrderInvoice = {
    subtotal,
    deliveryFee,
    restaurantServiceFee,
    platformFee,
    deliveryDiscount,
    promoDiscount,
    total: grandTotal
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString("id-ID");
  };

  const handleConfirmCheckout = () => {
    if (!selectedBranchId || checkoutItems.length === 0) return;
    
    // Fire checkout callback with custom grouped items
    onCheckout(invoice, driverNote, checkoutItems);

    // Simulate deleting checked out draft
    setDraftItemsMap(prev => {
      const copy = { ...prev };
      delete copy[selectedBranchId];
      return copy;
    });

    setSelectedBranchId(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      {/* Click outside listener */}
      <div className="absolute inset-0" onClick={onClose}></div>

      {/* Main Drawer Shell */}
      <div className="relative bg-white w-full max-w-md h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
        
        {/* VIEW 1: "DAFTAR PESANAN SAYA" (MULTI-CART RESTAURANT DRAFTS LIST - SCREENSHOT MATCH) */}
        {!selectedBranchId ? (
          <>
            {/* Header Area representing screenshot */}
            <div className="px-5 py-4.5 border-b border-gray-100 flex items-center justify-between bg-white shrink-0">
              <div className="flex items-center space-x-3.5">
                <button 
                  onClick={onClose}
                  className="p-1.5 -ml-1 text-gray-800 hover:bg-gray-100 rounded-full transition-colors cursor-pointer"
                  id="btn-close-drafts-list"
                >
                  <ArrowLeft className="h-5 w-5 stroke-[2.5]" />
                </button>
                <h2 className="font-extrabold text-gray-900 text-base sm:text-lg tracking-tight">Daftar Pesanan Saya</h2>
              </div>
              <button 
                onClick={onClose}
                className="text-xs sm:text-sm font-bold text-sky-600 hover:text-sky-700 hover:underline transition-colors cursor-pointer"
                id="btn-manage-drafts"
              >
                Atur
              </button>
            </div>

            {/* Scrollable Draft List */}
            <div className="flex-1 overflow-y-auto divide-y divide-gray-100 bg-white" id="drafts-scrollable-container">
              {allDraftsList.map((draft) => {
                const draftItems = getBranchItems(draft.branchId);
                if (draftItems.length === 0) return null;

                const menuCountText = `${draftItems.reduce((acc, x) => acc + x.quantity, 0)} menu`;

                return (
                  <div
                    key={draft.branchId}
                    onClick={() => setSelectedBranchId(draft.branchId)}
                    className="p-5 flex items-center justify-between gap-4 hover:bg-slate-50/50 cursor-pointer transition-all active:bg-slate-100"
                    id={`draft-restaurant-card-${draft.branchId}`}
                  >
                    {/* Left content area */}
                    <div className="flex-1 min-w-0 text-left space-y-1">
                      {/* Promos tag bullet list */}
                      <div className="flex flex-wrap items-center gap-x-1.5 text-[10px] sm:text-[11px] font-bold text-red-650 tracking-tight">
                        <span className="text-rose-600">🏷️ {draft.promos[0]}</span>
                        {draft.promos.slice(1).map((p, pIdx) => (
                          <span key={pIdx} className="text-orange-500">
                            • <span className="ml-[2px]">{p}</span>
                          </span>
                        ))}
                      </div>

                      {/* Restaurant Brand Title */}
                      <h3 className="font-extrabold text-sm sm:text-base text-gray-900 leading-snug tracking-tight truncate">
                        {draft.restaurantName} - {draft.branchName}
                      </h3>

                      {/* Meta information tags */}
                      <div className="flex items-center space-x-1.5 text-[10px] sm:text-[11px] text-gray-400 font-semibold uppercase tracking-wide">
                        <span className="text-gray-805 font-bold">{menuCountText}</span>
                        <span>•</span>
                        <span>{draft.avgDeliveryTime}</span>
                        <span>•</span>
                        <span>{draft.distance}</span>
                      </div>
                    </div>

                    {/* Right photo image container */}
                    <div className="h-[52px] w-[52px] sm:h-14 sm:w-14 rounded-xl overflow-hidden shrink-0 border border-gray-150/80 shadow-3xs bg-gray-50 flex items-center justify-center">
                      <SafeImage
                        type="logo"
                        src={draft.logo}
                        alt={draft.restaurantName}
                        className="h-full w-full object-cover"
                      />
                    </div>
                  </div>
                );
              })}

              {/* Empty state represents fully cleared shopping list */}
              {allDraftsList.every(d => getBranchItems(d.branchId).length === 0) && (
                <div className="py-24 px-8 text-center bg-gray-50/50 flex flex-col items-center">
                  <div className="h-16 w-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-4">
                    <ShoppingBag className="h-8 w-8 text-emerald-500" />
                  </div>
                  <h3 className="font-black text-gray-900 text-base">Keranjang & Draft Kosong</h3>
                  <p className="text-xs text-gray-500 mt-2 max-w-xs leading-normal">
                    Silakan kembali ke eksplor halaman belanja mitra, pilih outlet terfavorit, masukan ke list belanja untuk dipraktekan order!
                  </p>
                  <button 
                    onClick={onClose}
                    className="mt-6 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-5 py-3 rounded-xl shadow-lg transition-transform cursor-pointer"
                  >
                    Mulai Belanja
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          /* VIEW 2: DETAILED CHECKOUT PANEL VIEW FOR CHOSEN OPTION ("as in the web we make") */
          <>
            {/* Header with back button leading specifically to draft list! */}
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-white shrink-0">
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setSelectedBranchId(null)}
                  className="p-1.5 hover:bg-gray-100 rounded-full transition-all text-gray-700 cursor-pointer"
                  id="btn-back-to-drafts-list"
                >
                  <ArrowLeft className="h-5 w-5 stroke-[2.5]" />
                </button>
                <div>
                  <h2 className="font-black text-gray-900 text-sm sm:text-base leading-tight">Daftar Belanjaan</h2>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                    {activeBranchObj ? `${activeBranchObj.restaurantName} - ${activeBranchObj.branchName}` : ""}
                  </p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-full transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable details contents */}
            {checkoutItems.length > 0 ? (
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                
                {/* 1. Address summary info block */}
                <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-3xs space-y-3 text-left">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black tracking-wider text-emerald-600 uppercase">
                      LOKASI TUJUAN PENGANTARAN
                    </span>
                    <span className="bg-emerald-50 text-emerald-800 text-[10px] uppercase font-bold px-2 py-0.5 rounded-sm">
                      INSTANT 🏍️
                    </span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <MapPin className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                    <div className="min-w-0 flex-1">
                      <h4 className="font-extrabold text-gray-900 text-xs sm:text-sm">{currentLocation.label}</h4>
                      <p className="text-xs text-gray-500 truncate mt-1 leading-normal">{currentLocation.address}</p>
                    </div>
                  </div>

                  {/* Driver note */}
                  <div className="pt-2 border-t border-gray-100">
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wide">
                      Catatan Untuk Driver Gojek
                    </label>
                    <div className="flex items-center space-x-2 mt-1 bg-gray-50 p-2 rounded-xl border border-gray-100">
                      <Clipboard className="h-3.5 w-3.5 text-gray-400" />
                      <input
                        type="text"
                        value={driverNote}
                        onChange={(e) => setDriverNote(e.target.value)}
                        placeholder="Contoh: Bertemu di lobby depan pangkalan..."
                        className="bg-transparent border-none text-xs w-full text-gray-750 font-semibold focus:ring-0 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. Restaurant items list */}
                <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-3xs space-y-3 text-left">
                  <div className="flex items-center space-x-2 mb-1 pb-2 border-b border-gray-100">
                    <div className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span className="font-extrabold text-[#111111] text-xs sm:text-sm">
                      Daftar Menu yang Dipesan
                    </span>
                  </div>

                  <div className="space-y-4">
                    {checkoutItems.map((item, idx) => {
                      const uniqueItemId = `${item.menuItem.id}-${idx}`;
                      return (
                        <div key={uniqueItemId} className="flex justify-between items-start text-xs sm:text-sm">
                          <div className="flex-1 min-w-0 pr-3">
                            <div className="flex items-center">
                              <span className="font-black text-gray-950 mr-2">{item.quantity}x</span>
                              <span className="font-bold text-gray-800 truncate">{item.menuItem.name}</span>
                            </div>

                            {/* Options notes if custom */}
                            {item.notes && (
                              <p className="text-[10px] text-amber-700 font-semibold mt-1 pl-6 italic">
                                💡 Notes: "{item.notes}"
                              </p>
                            )}
                          </div>

                          {/* Price and controls */}
                          <div className="flex flex-col items-end shrink-0">
                            <span className="font-black text-gray-950">
                              Rp {formatPrice(item.menuItem.price * item.quantity)}
                            </span>

                            <div className="flex items-center space-x-1.5 mt-2 bg-gray-50 border border-gray-150 rounded-lg p-1">
                              <button
                                onClick={() => handleUpdateItemQty(item.branchId, item.menuItem.id, Math.max(1, item.quantity - 1))}
                                className="p-0.5 hover:bg-gray-100 text-gray-600 rounded-md transition-all"
                              >
                                <Minus className="h-3 w-3" />
                              </button>
                              <span className="text-xs font-black min-w-3 text-center">{item.quantity}</span>
                              <button
                                onClick={() => handleUpdateItemQty(item.branchId, item.menuItem.id, item.quantity + 1)}
                                className="p-0.5 hover:bg-gray-100 text-gray-600 rounded-md transition-all"
                              >
                                <Plus className="h-3 w-3" />
                              </button>
                              <button
                                onClick={() => handleRemoveItem(item.branchId, item.menuItem.id)}
                                className="p-1 text-red-500 hover:bg-red-50 rounded-md ml-1"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 3. Promo select block */}
                <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-3xs space-y-3 text-left">
                  <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center space-x-1.5">
                    <BadgePercent className="h-4 w-4 text-rose-500" />
                    <span>PILIH PROMO VOUCHER HEMAT</span>
                  </h4>

                  <div className="space-y-2">
                    <button
                      onClick={() => setPromoApplied("promo50")}
                      className={`w-full text-left p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                        promoApplied === "promo50"
                          ? "bg-rose-25 border-rose-500 text-rose-950 shadow-3xs"
                          : "border-gray-100 hover:bg-gray-50 text-gray-700 bg-white"
                      }`}
                    >
                      <div>
                        <span className="font-extrabold text-xs block text-rose-700">Promo Double Hemat 40%</span>
                        <span className="text-[10px] text-gray-400 font-semibold block mt-0.5">Potongan s/d 40rb + Free Ongkir Rp9.500</span>
                      </div>
                      <div className={`h-4 w-4 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        promoApplied === "promo50" ? "border-rose-500 bg-rose-500" : "border-gray-300"
                      }`}>
                        {promoApplied === "promo50" && <span className="h-1.5 w-1.5 bg-white rounded-full"></span>}
                      </div>
                    </button>

                    <button
                      onClick={() => setPromoApplied("ongkir10")}
                      className={`w-full text-left p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                        promoApplied === "ongkir10"
                          ? "bg-emerald-25 border-emerald-500 text-emerald-950 shadow-3xs"
                          : "border-gray-100 hover:bg-gray-50 text-gray-700 bg-white"
                      }`}
                    >
                      <div>
                        <span className="font-extrabold text-xs block text-emerald-800">Gratis Ongkir Rp9.500</span>
                        <span className="text-[10px] text-gray-450 font-semibold block mt-0.5 font-sans">Potongan ongkos kirim s/d Rp9.500 langsung</span>
                      </div>
                      <div className={`h-4 w-4 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        promoApplied === "ongkir10" ? "border-emerald-600 bg-emerald-600" : "border-gray-300"
                      }`}>
                        {promoApplied === "ongkir10" && <span className="h-1.5 w-1.5 bg-white rounded-full"></span>}
                      </div>
                    </button>

                    <button
                      onClick={() => setPromoApplied("none")}
                      className={`w-full text-left p-2 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                        promoApplied === "none"
                          ? "bg-gray-100 border-gray-400 text-gray-800"
                          : "border-gray-100 hover:bg-gray-50 text-gray-550 bg-white text-xs font-semibold"
                      }`}
                    >
                      <span>Jangan gunakan promo</span>
                      <div className={`h-4 w-4 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        promoApplied === "none" ? "border-gray-600 bg-gray-600" : "border-gray-300"
                      }`}>
                        {promoApplied === "none" && <span className="h-1.5 w-1.5 bg-white rounded-full"></span>}
                      </div>
                    </button>
                  </div>
                </div>

                {/* 4. Receipt detailed breakdown */}
                <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-3xs space-y-2 text-xs sm:text-sm text-gray-600 text-left">
                  <div className="flex items-center space-x-1.5 pb-2 mb-2 border-b border-gray-100">
                    <ReceiptText className="h-4 w-4 text-rose-500" />
                    <span className="font-black text-gray-900 text-xs">RINGKASAN PEMBAYARAN LENGKAP</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Subtotal Makanan</span>
                    <span className="font-bold text-gray-900">Rp {formatPrice(subtotal)}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Ongkos Kirim GoFood</span>
                    <span className="font-semibold text-gray-900">Rp {formatPrice(deliveryFee)}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Layanan Mitra & Resto</span>
                    <span className="font-semibold text-gray-900">Rp {formatPrice(restaurantServiceFee)}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Biaya Jasa Platform</span>
                    <span className="font-semibold text-gray-900">Rp {formatPrice(platformFee)}</span>
                  </div>

                  {deliveryDiscount < 0 && (
                    <div className="flex justify-between text-[#00aa5b] font-bold">
                      <span>Subsidi Gratis Ongkir</span>
                      <span>-Rp {formatPrice(Math.abs(deliveryDiscount))}</span>
                    </div>
                  )}

                  {promoDiscount > 0 && (
                    <div className="flex justify-between text-[#00aa5b] font-bold">
                      <span>Voucher Kuliner Makan 40%</span>
                      <span>-Rp {formatPrice(promoDiscount)}</span>
                    </div>
                  )}

                  <hr className="my-2 border-gray-100" />

                  <div className="flex justify-between text-sm sm:text-base font-black text-gray-950 pt-1">
                    <span>Total Pembayaran</span>
                    <div className="flex items-center space-x-1.5">
                      <span className="bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-lg text-[10px] font-bold uppercase">GoPay</span>
                      <span>Rp {formatPrice(invoice.total)}</span>
                    </div>
                  </div>
                </div>

                {/* 5. Payment method choose widget */}
                <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-3xs text-left">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-3">METODE PEMBAYARAN</span>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setPaymentMethod("gopay")}
                      className={`p-2.5 rounded-xl border text-xs font-black transition-all flex flex-col items-center justify-center space-y-1 cursor-pointer ${
                        paymentMethod === "gopay"
                          ? "bg-blue-50 border-blue-500 text-blue-900 shadow-3xs"
                          : "border-gray-100 bg-white hover:bg-gray-50 text-gray-500"
                      }`}
                    >
                      <span className="bg-blue-600 text-white text-[9px] font-black px-1.5 py-[1px] rounded-sm tracking-wider">GOPAY</span>
                      <span className="text-[9px] font-bold">Saldo Aktif</span>
                    </button>

                    <button
                      onClick={() => setPaymentMethod("ovo")}
                      className={`p-2.5 rounded-xl border text-xs font-black transition-all flex flex-col items-center justify-center space-y-1 cursor-pointer ${
                        paymentMethod === "ovo"
                          ? "bg-purple-50 border-purple-500 text-purple-900 shadow-3xs"
                          : "border-gray-100 bg-white hover:bg-gray-50 text-gray-500"
                      }`}
                    >
                      <span className="bg-purple-700 text-white text-[9px] font-black px-1.5 py-[1px] rounded-sm tracking-wider">OVO</span>
                      <span className="text-[9px] font-bold">OVO Cash</span>
                    </button>

                    <button
                      onClick={() => setPaymentMethod("cc")}
                      className={`p-2.5 rounded-xl border text-xs font-black transition-all flex flex-col items-center justify-center space-y-1 cursor-pointer ${
                        paymentMethod === "cc"
                          ? "bg-indigo-50 border-indigo-500 text-indigo-900 shadow-3xs"
                          : "border-gray-100 bg-white hover:bg-gray-50 text-gray-500"
                      }`}
                    >
                      <CreditCard className="h-4 w-4 text-indigo-600" />
                      <span className="text-[9px] font-bold">Credit/Debit</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-gray-50">
                <div className="h-16 w-16 bg-gray-100 text-gray-450 rounded-full flex items-center justify-center mb-4">
                  <ShoppingBag className="h-8 w-8" />
                </div>
                <h3 className="font-extrabold text-gray-900 text-base">Pesanan Ini Kosong</h3>
                <p className="text-xs text-gray-500 mt-2 max-w-xs leading-normal">
                  Semua menu di pesanan ini telah terhapus. Silakan kembali untuk memilih menu lain dari daftar resto.
                </p>
                <button 
                  onClick={() => setSelectedBranchId(null)}
                  className="mt-5 bg-emerald-600 hover:bg-emerald-700 font-bold py-2.5 px-5 rounded-xl text-xs text-white shadow-md transition-all cursor-pointer"
                >
                  Kembali ke Daftar Pesanan
                </button>
              </div>
            )}

            {/* Bottom Proceed Checkout button */}
            {checkoutItems.length > 0 && (
              <div className="p-5 border-t border-gray-150 bg-white shrink-0 shadow-lg text-left">
                <button 
                  onClick={handleConfirmCheckout}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black py-4 px-5 rounded-2xl text-xs sm:text-base flex items-center justify-between shadow-xl shadow-emerald-500/10 transition-all cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-sm">Rp {formatPrice(grandTotal)}</span>
                    <span className="text-[10px] text-emerald-200">|</span>
                    <span className="text-emerald-100 font-semibold">{checkoutItems.reduce((ac, item) => ac + item.quantity, 0)} Menu</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span>Pesan Sekarang!</span>
                    <ArrowRight className="h-4 w-4" />
                  </div>
                </button>
                <p className="text-[10px] text-gray-400 mt-2 text-center font-medium leading-relaxed">
                  Pesanan instan langsung dilempar ke driver Budi Setiawan terdekat untuk penjemputan super-cepat & steril.
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
