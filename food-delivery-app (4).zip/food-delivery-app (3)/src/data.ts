import { Restaurant, OrderHistoryItem, LocationProfile } from "./types";

export const locationProfiles: LocationProfile[] = [
  {
    id: "loc-1",
    label: "Kost",
    address: "Kost Twins Residence B11 Kemanggisan, Palmerah, Jakarta Barat"
  },
  {
    id: "loc-2",
    label: "Ruang Rasa, Blok D",
    address: "Ruang Rasa, Blok D, Jl. Mangga I No.9 Rt 08 Rw 03, Jakarta Selatan"
  },
  {
    id: "loc-3",
    label: "Kantor Pusat Gojek",
    address: "Gedung Pasar Festival Lantai 5, Rasuna Said, Kuningan, Jakarta Selatan"
  }
];

export const foodCategories = [
  { id: "viral", name: "Viral 🔥", icon: "https://images.unsplash.com/photo-1621996346565-e3bb69182a59?w=120&auto=format&fit=crop&q=80" },
  { id: "jajanan", name: "Jajanan", icon: "https://images.unsplash.com/photo-1541532713592-79a0317b6b77?w=120&auto=format&fit=crop&q=80" },
  { id: "cepat_saji", name: "Cepat saji", icon: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=120&auto=format&fit=crop&q=80" }
];

export const promoBanners = [
  {
    id: "p1",
    title: "MURAAM pakai GROUP ORDER",
    description: "Jajan bareng teman diskon s.d 40rb + Hemat Ongkir!",
    badge: "Jajan Barengan",
    discountTag: "Ongkir 100",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&auto=format&fit=crop&q=80",
    bgColor: "from-emerald-700 to-green-500"
  },
  {
    id: "p2",
    title: "Paket #TemaniHari 4 Kopi Susu",
    description: "Nikmati Kopi Susu andalan lokales mulai dari Rp 40rb!",
    badge: "Diskon 31%",
    discountTag: "Buy 1 Get 1",
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&auto=format&fit=crop&q=80",
    bgColor: "from-blue-700 to-indigo-500"
  },
  {
    id: "p3",
    title: "Daftar Kurasi Bintang 5 Gratis Ongkir",
    description: "Rating asli dari jutaan review pembeli langsung diantar cepat!",
    badge: "Kurasi Bintang 5",
    discountTag: "Discount 50%",
    image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop&q=80",
    bgColor: "from-orange-600 to-red-500"
  }
];

export const initialOrderHistory: OrderHistoryItem[] = [
  {
    id: "hist-2",
    restaurantId: "fore-coffee",
    restaurantName: "Fore Coffee (Kopi)",
    branchName: "OCBC NISP Kemanggisan",
    branchId: "fore-kemanggisan-branch",
    logo: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=120&auto=format&fit=crop&q=80",
    date: "18 Feb 2026, 15:26",
    status: "Selesai",
    itemsSummary: "1 Iced Bumi Latte, 1 Cakalang Quiche, 1 Iced Americano",
    totalPrice: 121400,
    savedAmount: 11500,
    items: [
      { name: "Iced Bumi Latte", quantity: 1, price: 32000, notes: "Less sweet, oat milk" },
      { name: "Cakalang Quiche", quantity: 1, price: 42000 },
      { name: "Iced Americano", quantity: 1, price: 29000, notes: "No sugar" }
    ],
    rating: 4
  }
];

export const restaurantsData: Restaurant[] = [
  {
    id: "sec-bowl",
    brandName: "Sec Bowl",
    logo: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=100&auto=format&fit=crop&q=80",
    bannerImage: "https://images.unsplash.com/photo-1612087054470-70a14a95912c?w=1000&auto=format&fit=crop&q=80",
    categoryTags: ["Cepat saji"],
    isHalal: true,
    rating: 4.9,
    isPlusMember: true,
    branches: [
      {
        id: "sec-bowl-kemanggisan",
        name: "Kemanggisan",
        address: "Jl. Kemanggisan Utama No. 12, Palmerah, Jakarta Barat",
        distance: 1.4,
        avgDeliveryTime: "15-25 min",
        rating: 4.9,
        ratingCount: "6rb+ ratings",
        deliveryFee: 5500,
        deliveryFeeOriginal: 15500,
        promos: ["Diskon makanan 31% s.d. 49rb", "Gratis Ongkir min. 40rb"],
        isOpen: true
      },
      {
        id: "sec-bowl-tanjung-duren",
        name: "Tanjung Duren",
        address: "Jl. Tanjung Duren Raya No. 45, Grogol Petamburan, Jakarta Barat",
        distance: 2.8,
        avgDeliveryTime: "20-30 min",
        rating: 4.8,
        ratingCount: "4rb+ ratings",
        deliveryFee: 8000,
        deliveryFeeOriginal: 18000,
        promos: ["Diskon makanan 25% s.d. 30rb"],
        isOpen: true
      },
      {
        id: "sec-bowl-sudirman",
        name: "Sudirman Mall",
        address: "Sudirman Central Plaza L2, Kebayoran Baru, Jakarta Selatan",
        distance: 5.2,
        avgDeliveryTime: "30-40 min",
        rating: 4.9,
        ratingCount: "10rb+ ratings",
        deliveryFee: 12000,
        deliveryFeeOriginal: 22000,
        promos: ["Ongkir Ringan 3rb", "Diskon 31%"],
        isOpen: true
      }
    ],
    menu: [
      {
        id: "sec-m1",
        name: "Salted Egg Chicken Box",
        description: "Ayam goreng renyah disiram saus telur asin khas Sec Bowl yang gurih, creamy, dan nikmat, disajikan dengan nasi hangat dan telur mata sapi setengah matang.",
        price: 58500,
        image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400&auto=format&fit=crop&q=80",
        category: "Best Seller 🌟",
        tags: ["Recommended", "Saus Padat"],
        customizationOptions: [
          { name: "Kematangan Telur", choices: ["Setengah Mateng", "Mateng"], required: true },
          { name: "Tingkat Kepedasan", choices: ["No Spicy", "Spicy (Sambal di Dalam)", "Spicy Dipisah"], required: true }
        ]
      },
      {
        id: "sec-m2",
        name: "Salted Egg Chicken Polos",
        description: "Porsi ala carte Ayam Saus Telur Asin khas Sec Bowl tanpa nasi dan telur. Includes FREE 1 Extra Salted Egg Sauce. Tanpa cabe rawit di dalam saus.",
        price: 42800,
        originalPrice: 53500,
        image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400&auto=format&fit=crop&q=80",
        category: "Flash Sale 🔥",
        isFlashSale: true,
        discountPercentage: 20,
        tags: ["Promo Maks. 5", "Non Pedas"],
        customizationOptions: [
          { name: "Sambal Tambahan", choices: ["Tanpa cabe rawit", "Tambah Sambal Rawit (+Rp2.000)"], required: false }
        ]
      },
      {
        id: "sec-m3",
        name: "Extra Salted Egg Sauce",
        description: "Saus telur asin gurih yang kental dan gurih nagih khas Sec Bowl dalam cup terpisah.",
        price: 15000,
        image: "https://images.unsplash.com/photo-1589182337358-2ca6e794c8e5?w=400&auto=format&fit=crop&q=80",
        category: "Tambahan"
      }
    ]
  },
  {
    id: "kfc",
    brandName: "KFC",
    logo: "https://images.unsplash.com/photo-1513639773648-2b98865be901?w=100&auto=format&fit=crop&q=80",
    bannerImage: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1000&auto=format&fit=crop&q=80",
    categoryTags: ["Cepat saji"],
    isHalal: true,
    rating: 4.6,
    isPlusMember: true,
    branches: [
      {
        id: "kfc-s-parman",
        name: "S Parman",
        address: "Jl. Letjen S. Parman No. Kav 21, Petamburan, Palmerah, Jakarta Barat",
        distance: 1.1,
        avgDeliveryTime: "15-25 min",
        rating: 4.5,
        ratingCount: "3rb+ ratings",
        deliveryFee: 6000,
        deliveryFeeOriginal: 16000,
        promos: ["Diskon Rp30.000", "Gratis Ongkir Rp6.000"],
        isOpen: true
      },
      {
        id: "kfc-tanjung-duren",
        name: "Tanjung Duren",
        address: "Jl. Tanjung Duren Barat No. 8, Jakarta Barat",
        distance: 1.8,
        avgDeliveryTime: "20-30 min",
        rating: 4.6,
        ratingCount: "9rb+ ratings",
        deliveryFee: 9000,
        deliveryFeeOriginal: 19000,
        promos: ["Diskon Rp30.000", "Gratis Ongkir Rp9.000"],
        isOpen: true
      },
      {
        id: "kfc-cideng",
        name: "Cideng Jakarta",
        address: "Jl. Cideng Timur No. 34, Cideng, Gambir, Jakarta Pusat",
        distance: 3.2,
        avgDeliveryTime: "25-35 min",
        rating: 4.6,
        ratingCount: "9rb+ ratings",
        deliveryFee: 9000,
        deliveryFeeOriginal: 19000,
        promos: ["Diskon Rp30.000", "Gratis Ongkir Rp9.000"],
        isOpen: true
      },
      {
        id: "kfc-panjang",
        name: "Jalan Panjang",
        address: "Jl. Panjang Raya No. 12, Kebon Jeruk, Jakarta Barat",
        distance: 3.9,
        avgDeliveryTime: "28-38 min",
        rating: 4.6,
        ratingCount: "8rb+ ratings",
        deliveryFee: 9000,
        deliveryFeeOriginal: 19000,
        promos: ["Diskon Rp30.000", "Bonus Puding Lipat"],
        isOpen: true
      }
    ],
    menu: [
      {
        id: "kfc-m1",
        name: "Paket Super Besar 1",
        description: "1 Pcs Crispy/O.R. Chicken + 1 Nasi + 1 Coca Cola Medium.",
        price: 38500,
        originalPrice: 48000,
        image: "https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?w=400&auto=format&fit=crop&q=80",
        category: "Promo Special 🍗",
        isPopular: true,
        isFlashSale: true,
        discountPercentage: 20,
        customizationOptions: [
          { name: "Pilihan Ayam", choices: ["Crispy", "Original Recipe O.R."], required: true },
          { name: "Pilihan Potongan", choices: ["Dada", "Paha Atas", "Sayap", "Paha Bawah"], required: false }
        ]
      },
      {
        id: "kfc-m2",
        name: "Winger Crispy Ayam",
        description: "4 potong sayap ayam renyah (2 Sayap utuh dipotong dua) bumbu marinasi crispy super nikmat.",
        price: 24000,
        image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400&auto=format&fit=crop&q=80",
        category: "Ala Carte"
      },
      {
        id: "kfc-m3",
        name: "Colonel Burger",
        description: "Set roti bun lembut berisi crispy chicken fillet gurih dengan selada segar dan lumuran saus mayones khas KFC.",
        price: 29000,
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&auto=format&fit=crop&q=80",
        category: "Burgers & more"
      },
      {
        id: "kfc-m4",
        name: "Crispy Strips (3 Pcs)",
        description: "3 Potong daging dada ayam tanpa tulang berbalur tepung krispi renyah.",
        price: 32000,
        image: "https://images.unsplash.com/photo-1562967914-608f82629710?w=400&auto=format&fit=crop&q=80",
        category: "Snack & Desserts"
      }
    ]
  },
  {
    id: "fore-coffee",
    brandName: "Fore Coffee (Kopi)",
    logo: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=100&auto=format&fit=crop&q=80",
    bannerImage: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=1000&auto=format&fit=crop&q=80",
    categoryTags: ["Jajanan"],
    isHalal: true,
    rating: 4.9,
    isPlusMember: true,
    branches: [
      {
        id: "fore-kemanggisan-branch",
        name: "OCBC NISP Kemanggisan",
        address: "Gedung OCBC NISP, Jl. Kemanggisan Raya No. 4, Jakarta Barat",
        distance: 1.5,
        avgDeliveryTime: "15-20 min",
        rating: 4.9,
        ratingCount: "4rb+ ratings",
        deliveryFee: 5000,
        deliveryFeeOriginal: 15000,
        promos: ["Diskon 25%", "Hemat Ongkir Rp10.000"],
        isOpen: true
      },
      {
        id: "fore-binus",
        name: "Binus Syahdan",
        address: "Jl. K.H. Syahdan No. 35, Palmerah, Jakarta Barat",
        distance: 1.9,
        avgDeliveryTime: "15-25 min",
        rating: 4.8,
        ratingCount: "2rb+ ratings",
        deliveryFee: 5000,
        deliveryFeeOriginal: 15000,
        promos: ["Gratis Ongkir"],
        isOpen: true
      }
    ],
    menu: [
      {
        id: "fore-m1",
        name: "Iced Bumi Latte",
        description: "Espresso spesial dikombinasikan dengan susu segar premium dan sirup gula aren alami khas Fore.",
        price: 32000,
        image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&auto=format&fit=crop&q=80",
        category: "Best Seller ☕",
        isPopular: true,
        customizationOptions: [
          { name: "Jenis Susu", choices: ["Regular Fresh Milk", "Oatmilk (+Rp6.000)", "Soymilk (+Rp5.000)"], required: true },
          { name: "Takaran Manis", choices: ["Normal Sweetness", "Less Sweet", "No Sugar"], required: true }
        ]
      },
      {
        id: "fore-m2",
        name: "Cakalang Quiche",
        description: "Tarta gurih khas Perancis yang dipanggang renyah berisikan suwiran ikan cakalang pedas aromatik nusantara.",
        price: 42000,
        image: "https://images.unsplash.com/photo-1608039829572-78524f79c4c7?w=400&auto=format&fit=crop&q=80",
        category: "Savory Pastries"
      },
      {
        id: "fore-m3",
        name: "Iced Americano",
        description: "Double shot espresso blend arabika premium Fore dengan air es dan es batu.",
        price: 29000,
        image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=400&auto=format&fit=crop&q=80",
        category: "Coffee Classic"
      },
      {
        id: "fore-m4",
        name: "Sunny Burst Orange Tea",
        description: "Teh melati seduh berkualitas yang dipadukan dengan konsentrat jeruk mandarin segar dan irisan citrus.",
        price: 35000,
        image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&auto=format&fit=crop&q=80",
        category: "Non-Coffee Signature"
      }
    ]
  },
  {
    id: "jco-slipi",
    brandName: "JCO",
    logo: "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=100&auto=format&fit=crop&q=80",
    bannerImage: "https://images.unsplash.com/photo-1621569656339-e9323dfde63b?w=1000&auto=format&fit=crop&q=80",
    categoryTags: ["Jajanan"],
    isHalal: true,
    rating: 4.9,
    branches: [
      {
        id: "jco-slipi-branch-1",
        name: "Slipi Jaya",
        address: "Plaza Slipi Jaya L1, Jl. Letjen S. Parman Kav. 17, Slipi, Palmerah, Jakarta Barat",
        distance: 1.7,
        avgDeliveryTime: "15-25 min",
        rating: 4.9,
        ratingCount: "5rb+ ratings",
        deliveryFee: 5500,
        deliveryFeeOriginal: 15500,
        promos: ["Hemat Rp35.800", "Ongkir Murah 5rb"],
        isOpen: true
      }
    ],
    menu: [
      {
        id: "jco-m1",
        name: "Donuts 1 Dzn",
        description: "Pilihan 12 pcs donat artisan aneka rasa favorit Anda (Alcapone, Oreology, Avocado Dicaprio, dll).",
        price: 88000,
        image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=400&auto=format&fit=crop&q=80",
        category: "Sharing Pack",
        isPopular: true
      },
      {
        id: "jco-m2",
        name: "Donuts 2 Dzn",
        description: "Pilihan 24 pcs donat artisan premium aneka rasa, sangat pas untuk berbagi bersama keluarga atau kantor.",
        price: 164700,
        image: "https://images.unsplash.com/photo-1621569656339-e9323dfde63b?w=400&auto=format&fit=crop&q=80",
        category: "Sharing Pack",
        tags: ["Best Value"]
      }
    ]
  }
];
