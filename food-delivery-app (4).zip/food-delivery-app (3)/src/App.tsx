import { useState } from "react";
import { 
  Search, Star, MapPin, BadgePercent, ShieldCheck, ChevronRight, 
  UtensilsCrossed, Sparkles, Navigation, Clock, Receipt, RefreshCw 
} from "lucide-react";

import { Restaurant, Branch, MenuItem, CartItem, OrderInvoice, OngoingOrder, OrderHistoryItem, User } from "./types";
import { restaurantsData, initialOrderHistory, locationProfiles, foodCategories, promoBanners } from "./data";
import SafeImage from "./components/SafeImage";

import Navbar from "./components/Navbar";
import BranchGroupModal from "./components/BranchGroupModal";
import RestaurantDetailView from "./components/RestaurantDetailView";
import CheckoutInvoicePanel from "./components/CheckoutInvoicePanel";
import LiveTrackingView from "./components/LiveTrackingView";
import OrderHistoryView from "./components/OrderHistoryView";
import CategoryDetailView from "./components/CategoryDetailView";
import AuthModal from "./components/AuthModal";

export default function App() {
  // Navigation & Location States
  const [activeTab, setActiveTab] = useState<"home" | "history" | "tracking">("home");
  const [currentLocation, setCurrentLocation] = useState(locationProfiles[0]);
  const [selectedCategoryPage, setSelectedCategoryPage] = useState<{ id: string; name: string } | null>(null);

  // User Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const stored = localStorage.getItem("gofood_current_user");
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        return null;
      }
    }
    return null;
  });
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  
  // Filtering & Searching States
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [selectedPromoBanner, setSelectedPromoBanner] = useState<string | null>(null);

  // Selector States for grouped restaurants
  const [activeRestaurant, setActiveRestaurant] = useState<Restaurant | null>(null);
  const [activeBranch, setActiveBranch] = useState<Branch | null>(null);
  const [inspectingRestaurant, setInspectingRestaurant] = useState<Restaurant | null>(null);

  // Cart Management
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Active Live Order Track State
  const [ongoingOrder, setOngoingOrder] = useState<OngoingOrder | null>(null);

  // Historical Orders list state (for rating star feeds & Pesan Lagi triggers)
  const [historyList, setHistoryList] = useState<OrderHistoryItem[]>(initialOrderHistory);

  // --- Cart action functions ---
  const handleAddToCart = (
    item: MenuItem,
    quantity: number,
    notes: string,
    selectedCustomizations: { [optionName: string]: string }
  ) => {
    if (!activeRestaurant || !activeBranch) return;

    setCart((prevCart) => {
      const baseCart = [...prevCart];

      const existingIndex = baseCart.findIndex(
        (x) => x.branchId === activeBranch.id &&
        x.menuItem.id === item.id && 
        JSON.stringify(x.selectedCustomizations) === JSON.stringify(selectedCustomizations)
      );

      if (existingIndex > -1) {
        const updated = [...baseCart];
        updated[existingIndex].quantity += quantity;
        updated[existingIndex].notes = notes || updated[existingIndex].notes;
        return updated;
      }

      const newItem: CartItem = {
        menuItem: item,
        restaurantId: activeRestaurant.id,
        restaurantName: activeRestaurant.brandName,
        branchId: activeBranch.id,
        branchName: activeBranch.name,
        quantity,
        notes,
        selectedCustomizations
      };
      return [...baseCart, newItem];
    });
  };

  const handleUpdateCartItemQuantity = (branchId: string, itemId: string, quantity: number) => {
    setCart((prev) => 
      prev.map((item) => (item.branchId === branchId && item.menuItem.id === itemId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveCartItem = (branchId: string, itemId: string) => {
    setCart((prev) => prev.filter((item) => !(item.branchId === branchId && item.menuItem.id === itemId)));
  };

  // --- Select grouped branch handler ---
  const handleSelectBranch = (restaurant: Restaurant, branch: Branch) => {
    setActiveRestaurant(restaurant);
    setActiveBranch(branch);
    setInspectingRestaurant(null); // Close the branch modal
  };

  // --- Proceed checkout submit ---
  const handleCheckout = (invoice: OrderInvoice, driverNote: string, checkoutItems?: CartItem[]) => {
    if (!currentUser) {
      setIsCartOpen(false); // Close cart drawer
      setIsAuthOpen(true);  // Prompt authentication modal
      return;
    }

    const activeItems = checkoutItems || cart;
    if (activeItems.length === 0) return;

    const newOrder: OngoingOrder = {
      id: `ord-${Math.floor(Math.random() * 90000) + 10000}`,
      restaurantName: activeItems[0].restaurantName,
      branchName: activeItems[0].branchName,
      logo: activeItems[0].menuItem.image,
      orderCode: `GF-${Math.floor(Math.random() * 900) + 100}`,
      driverName: "Budi Setiawan",
      driverPhoto: "https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=120&auto=format&fit=crop&q=80",
      driverPlate: "B 3824 SWB",
      driverRating: 4.9,
      driverPhone: "+628123456789",
      status: "Diproses Resto",
      statusText: "Restoran sedang menyiapkan hidangan lezatmu...",
      eta: "15-20 min",
      currentPin: "resto",
      items: activeItems.map((x) => ({
        name: x.menuItem.name,
        quantity: x.quantity,
        price: x.menuItem.price,
        notes: x.notes
      })),
      invoice,
      customerAddress: currentLocation.label,
      driverNote: driverNote || "Bertemu di depan pintu."
    };

    setOngoingOrder(newOrder);
    
    // Clear checked-out items only
    const branchId = activeItems[0].branchId;
    setCart((prev) => prev.filter((x) => x.branchId !== branchId));
    setIsCartOpen(false);
    setActiveTab("tracking");
  };

  // --- Simulated status update timeline ---
  const handleSimulateNextStage = () => {
    if (!ongoingOrder) return;

    setOngoingOrder((prev) => {
      if (!prev) return null;
      if (prev.status === "Diproses Resto") {
        return {
          ...prev,
          status: "Driver Menjemput",
          statusText: "Budi Setiawan sedang mengambil pesananmu di outlet restoran...",
          eta: "10-15 min",
          currentPin: "resto"
        };
      } else if (prev.status === "Driver Menjemput") {
        return {
          ...prev,
          status: "Diantar",
          statusText: "Budi Setiawan sedang berkendara menuju tempat hunianmu...",
          eta: "5-10 min",
          currentPin: "on_the_way"
        };
      } else if (prev.status === "Diantar") {
        return {
          ...prev,
          status: "Sampai",
          statusText: "Pesananmu sudah sampai! Silakan nikmati hidangan lezatmu.",
          eta: "Tiba",
          currentPin: "delivered"
        };
      }
      return prev;
    });

    // If transitioned to arrived, add to history log
    if (ongoingOrder.status === "Diantar") {
      const savedAmount = ongoingOrder.invoice.deliveryDiscount + ongoingOrder.invoice.promoDiscount;
      const finalHistoryItem: OrderHistoryItem = {
        id: ongoingOrder.id,
        restaurantId: activeRestaurant?.id || "unknown",
        restaurantName: ongoingOrder.restaurantName,
        branchName: ongoingOrder.branchName,
        branchId: activeBranch?.id || "unknown",
        logo: ongoingOrder.logo,
        date: new Date().toLocaleString("id-ID", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }),
        status: "Selesai",
        itemsSummary: ongoingOrder.items.map((x) => `${x.quantity}x ${x.name}`).join(", "),
        totalPrice: ongoingOrder.invoice.total,
        savedAmount: Math.abs(savedAmount),
        items: ongoingOrder.items.map((x) => ({
          name: x.name,
          quantity: x.quantity,
          price: x.price,
          notes: x.notes
        })),
        rating: 5 // Default rated
      };

      setHistoryList((prev) => [finalHistoryItem, ...prev]);
    }
  };

  const handleCancelOrder = () => {
    setOngoingOrder(null);
    setActiveTab("home");
  };

  // --- Past Order Re-order handler ---
  const handleReorder = (historyItem: OrderHistoryItem) => {
    // Look up target restaurant
    const foundResto = restaurantsData.find((r) => r.id === historyItem.restaurantId);
    const foundBranch = foundResto?.branches.find((b) => b.id === historyItem.branchId) || foundResto?.branches[0];

    if (foundResto && foundBranch) {
      setActiveRestaurant(foundResto);
      setActiveBranch(foundBranch);
      
      // Map structures back into cart
      const remappedItems: CartItem[] = historyItem.items.map((hi) => {
        const correspondingMenuItem = foundResto.menu.find((m) => m.name === hi.name) || {
          id: `item-${Math.random()}`,
          name: hi.name,
          price: hi.price,
          description: "Sajian andalan kuliner terfavorit",
          image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=150",
          category: "Lainnya"
        };

        return {
          menuItem: correspondingMenuItem,
          restaurantId: foundResto.id,
          restaurantName: foundResto.brandName,
          branchId: foundBranch.id,
          branchName: foundBranch.name,
          quantity: hi.quantity,
          notes: hi.notes || "",
          selectedCustomizations: {}
        };
      });

      setCart(remappedItems);
      setIsCartOpen(true);
      setActiveTab("home");
    }
  };

  // --- Rate order from history stars feedback ---
  const handleRateOrder = (orderId: string, rating: number) => {
    setHistoryList((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, rating } : ord))
    );
  };

  // Filter restaurants shown on homepage based on Search and Selected Category Badge
  const filteredRestaurants = restaurantsData.filter((resto) => {
    const matchesSearch = 
      resto.brandName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resto.categoryTags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      resto.menu.some((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = 
      !activeCategory || 
      resto.categoryTags.includes(activeCategory) || 
      (activeCategory === "Kopi" && resto.categoryTags.includes("Kopi Lokal")) ||
      (activeCategory === "Ayam Geprek" && resto.categoryTags.includes("Ayam")) ||
      (activeCategory === "Viral 🔥" && resto.rating >= 4.8);

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50/50 text-gray-800 antialiased font-sans">
      
      {/* Dynamic Navbar */}
      <Navbar
        currentLocation={currentLocation}
        onChangeLocation={setCurrentLocation}
        activeTab={activeTab}
        setActiveTab={(t) => {
          setActiveTab(t);
          if (t === "home") {
            setActiveRestaurant(null); // return to shop listing
            setActiveBranch(null);
            setSelectedCategoryPage(null);
          }
        }}
        cart={cart}
        setIsCartOpen={setIsCartOpen}
        onOpenStoreWithId={(id, bId) => {
          const r = restaurantsData.find((x) => x.id === id);
          const b = r?.branches.find((x) => x.id === bId);
          if (r && b) {
            setActiveRestaurant(r);
            setActiveBranch(b);
            setActiveTab("home");
          }
        }}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={() => {
          setCurrentUser(null);
          localStorage.removeItem("gofood_current_user");
        }}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Navigation router states */}

        {/* 1. RESTAURANT DETAIL VIEW */}
        {activeTab === "home" && activeRestaurant && activeBranch ? (
          <RestaurantDetailView
            restaurant={activeRestaurant}
            selectedBranch={activeBranch}
            onBack={() => {
              setActiveRestaurant(null);
              setActiveBranch(null);
            }}
            onAddToCart={handleAddToCart}
          />
        ) : activeTab === "home" && selectedCategoryPage ? (
          <CategoryDetailView
            categoryId={selectedCategoryPage.id}
            categoryName={selectedCategoryPage.name}
            restaurants={restaurantsData}
            onBack={() => setSelectedCategoryPage(null)}
            onSelectRestaurant={(restaurant, branch) => {
              setActiveRestaurant(restaurant);
              setActiveBranch(branch);
            }}
          />
        ) : activeTab === "home" ? (
          
          /* 2. CHOOSE HOMEPAGE MAIN */
          <div className="space-y-8">
            
            {/* Display Hero search layout */}
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-emerald-800 via-green-700 to-emerald-600 text-white p-6 sm:p-10 shadow-xl">
              {/* Background abstract accents */}
              <div className="absolute top-0 right-0 h-40 w-44 bg-white/5 rounded-full blur-2xl"></div>
              <div className="absolute -bottom-6 -left-10 h-32 w-32 bg-yellow-400/10 rounded-full blur-xl"></div>

              <div className="max-w-xl space-y-4 relative z-10">
                <span className="bg-emerald-600/60 text-emerald-100 font-extrabold text-[10px] sm:text-xs px-3 py-1 rounded-full uppercase tracking-widest inline-flex items-center space-x-1.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>GoFood Official Partner 2026</span>
                </span>
                <h1 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
                  Laper Pol? Pesan Kuliner Lokal Enak, Cepat Terjamin!
                </h1>
                <p className="text-xs sm:text-sm text-emerald-150 leading-relaxed max-w-md">
                  Ayam Tepung Crispy Sec Bowl, Mie Gacoan Level 4, Donuts J.CO, atau Kopi Tuku. Hangat nikmat langsung meluncur ke rumahmu.
                </p>

                {/* Hero Search Input */}
                <div className="relative max-w-md pt-2">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    placeholder="Mau jajan apa hari ini? Contoh: 'Sec Bowl', 'Kopi', 'Mie'..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 bg-white text-gray-800 rounded-2xl border-none focus:outline-none focus:ring-4 focus:ring-emerald-400 shadow-lg text-xs sm:text-sm transition-all"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery("")}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-450 hover:text-gray-600"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Food Horizontal Category Circle badging */}
            <div className="space-y-3">
              <div className="flex justify-between items-center pr-2">
                <h3 className="font-black text-gray-950 text-sm sm:text-base uppercase tracking-wider flex items-center space-x-1.5">
                  <span className="text-emerald-600">🍕</span>
                  <span>Kategori Makanan Terlaris</span>
                </h3>
                {activeCategory && (
                  <button 
                    onClick={() => setActiveCategory(null)}
                    className="text-emerald-700 text-xs font-black hover:underline"
                  >
                    Reset Filter
                  </button>
                )}
              </div>

              <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none">
                {foodCategories.map((cat) => {
                  const isSelected = activeCategory === cat.name;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setSelectedCategoryPage({ id: cat.id, name: cat.name });
                      }}
                      className="group flex flex-col items-center space-y-2 shrink-0 transition-all focus:outline-none cursor-pointer"
                    >
                      <div className={`h-16 w-16 sm:h-20 sm:w-20 rounded-2xl overflow-hidden border-2 p-1 bg-white relative transition-all group-hover:scale-105 group-active:scale-95 flex items-center justify-center ${
                        isSelected 
                          ? "border-emerald-600 bg-emerald-50 shadow-md ring-2 ring-emerald-500/10" 
                          : "border-gray-150 hover:border-gray-300 shadow-3xs"
                      }`}>
                        <SafeImage 
                          type="food"
                          src={cat.icon} 
                          alt={cat.name} 
                          className="h-full w-full object-cover rounded-xl"
                        />
                        {isSelected && (
                          <div className="absolute top-1 right-1 h-3.5 w-3.5 bg-emerald-650 text-white rounded-full flex items-center justify-center text-[8px] font-bold">
                            ✓
                          </div>
                        )}
                      </div>
                      <span className={`text-[10px] sm:text-xs font-extrabold tracking-wide ${isSelected ? "text-emerald-700" : "text-gray-700 font-medium"}`}>
                        {cat.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sticky interactive promo banner slider */}
            <div className="space-y-3">
              <h3 className="font-black text-gray-950 text-sm sm:text-base uppercase tracking-wider flex items-center space-x-1.5">
                <span className="text-emerald-600">🎟️</span>
                <span>Promo Kilat Hari Ini</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {promoBanners.map((promo) => (
                  <div
                    key={promo.id}
                    className="bg-white hover:border-emerald-500 relative rounded-3xl overflow-hidden border border-gray-150 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                  >
                    <div className="p-4 sm:p-5 flex gap-3">
                      <div className="flex-1 min-w-0">
                        <span className="bg-red-50 text-red-700 text-[9px] font-black uppercase px-2 py-0.5 rounded-sm">
                          {promo.badge}
                        </span>
                        <h4 className="font-extrabold text-gray-900 text-sm mt-1.5 leading-snug">
                          {promo.title}
                        </h4>
                        <p className="text-[11px] text-gray-500 mt-1 line-clamp-2">
                          {promo.description}
                        </p>
                      </div>
                      
                      <SafeImage 
                        type="banner"
                        src={promo.image} 
                        alt={promo.title} 
                        className="h-16 w-16 rounded-xl object-cover shrink-0"
                      />
                    </div>

                    <div className="bg-emerald-50 border-t border-emerald-50/50 p-3 px-5 flex items-center justify-between text-xs font-bold text-emerald-800 shrink-0">
                      <span>🎟️ Promo Tag: {promo.discountTag}</span>
                      <ChevronRight className="h-4 w-4" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* List of recommended brands with grouped outlets */}
            <div className="space-y-5">
              <hr className="border-gray-100" />
              
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="font-black text-gray-950 text-base sm:text-lg uppercase tracking-wider flex items-center space-x-1.5">
                    <span className="text-emerald-600">🔥</span>
                    <span>Rekomendasi Kuliner Terlaris Sekitarmu</span>
                  </h2>
                  <p className="text-xs text-gray-450 font-medium font-semibold">Berdasarkan pemesanan di Kost saat ini</p>
                </div>

                <div className="text-xs text-gray-400 font-semibold">
                  Menampilkan {filteredRestaurants.length} Brands
                </div>
              </div>

              {/* Grouped Branch layout cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredRestaurants.map((resto) => {
                  const primaryBranch = resto.branches[0];

                  return (
                    <div
                      key={resto.id}
                      onClick={() => setInspectingRestaurant(resto)}
                      className="bg-white border text-left border-gray-150 rounded-3xl overflow-hidden shadow-xs hover:shadow-lg hover:border-emerald-500 hover:ring-2 hover:ring-emerald-500/5 transition-all flex flex-col justify-between group cursor-pointer relative"
                    >
                      {/* Banner Image Container */}
                      <div className="relative h-40">
                        <SafeImage
                          type="banner"
                          src={resto.bannerImage}
                          alt={resto.brandName}
                          className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                        {/* Badging indicator */}
                        <div className="absolute top-3 left-3 flex gap-1.5">
                          {resto.isPlusMember && (
                            <span className="bg-emerald-600 text-white font-extrabold text-[9px] uppercase px-2 py-0.5 rounded-full tracking-wider">
                              Plus Member
                            </span>
                          )}
                          {resto.isHalal && (
                            <span className="bg-orange-50 text-orange-900 border border-orange-200/50 font-extrabold text-[9px] px-1.5 py-0.5 rounded-sm uppercase tracking-wide">
                              HALAL
                            </span>
                          )}
                        </div>

                        {/* Bottom restaurant logos */}
                        <div className="absolute bottom-3 left-3 right-3 flex items-center space-x-2.5">
                          <SafeImage
                            type="logo"
                            src={resto.logo}
                            alt={resto.brandName + " logo"}
                            className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl object-cover bg-white p-0.5 shadow border border-gray-100 shrink-0"
                          />
                          <div>
                            <h3 className="font-extrabold text-white text-sm sm:text-base drop-shadow-sm flex items-center">
                              {resto.brandName}
                            </h3>
                            <span className="text-[10px] text-gray-200 block drop-shadow-xs font-semibold">
                              {resto.categoryTags.join(" • ")}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Info & Outlets selector drawer layout */}
                      <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                        
                        {/* Rating block & Logistics estimate */}
                        <div className="flex flex-wrap items-center justify-between gap-2.5 text-xs">
                          <div className="flex items-center space-x-1 font-bold text-gray-900">
                            <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                            <span>{resto.rating}</span>
                            <span className="text-gray-450 font-normal">({primaryBranch.ratingCount})</span>
                          </div>

                          <div className="flex items-center text-gray-550 font-medium">
                            <Clock className="h-3.5 w-3.5 mr-1" />
                            <span>Est. {primaryBranch.avgDeliveryTime}</span>
                          </div>
                        </div>

                        {/* Main Branch promos */}
                        {primaryBranch.promos.length > 0 && (
                          <div className="bg-red-50 text-red-700 px-2.5 py-1.5 rounded-xl text-[11px] font-black flex items-center space-x-1">
                            <BadgePercent className="h-4 w-4 shrink-0" />
                            <span className="truncate">{primaryBranch.promos[0]}</span>
                          </div>
                        )}

                        <hr className="border-gray-100" />

                        {/* Outlet selector drawer trigger element */}
                        <div className="flex items-center justify-between pt-1">
                          <div className="min-w-0 pr-2">
                            <span className="text-[10px] text-gray-400 font-bold block uppercase tracking-wider">
                              Grouped Branches Outlets
                            </span>
                            <span className="text-xs font-extrabold text-emerald-700 block truncate mt-0.5">
                              Ada {resto.branches.length} cabang terdekat kamu
                            </span>
                          </div>

                          <div className="bg-gray-100 text-gray-600 font-extrabold text-[10px] px-2.5 py-1.5 rounded-xl whitespace-nowrap hover:bg-emerald-600 hover:text-white transition-all">
                            Pilih Cabang
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {filteredRestaurants.length === 0 && (
                  <div className="col-span-full py-16 text-center bg-white rounded-3xl border border-gray-200">
                    <UtensilsCrossed className="h-10 w-10 text-gray-450 mx-auto" />
                    <h3 className="font-extrabold text-gray-900 text-base mt-3">Kuliner tidak ditemukan</h3>
                    <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
                      Coba cari menu lain, hilangkan filter tipe kategori penelusuran, atau periksa keyword pencarianmu.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Quality assurance certification section */}
            <div className="bg-emerald-50 border border-emerald-100 rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center gap-5 justify-between">
              <div className="flex items-center space-x-4 text-center sm:text-left">
                <div className="h-12 w-12 bg-white text-emerald-600 rounded-full flex items-center justify-center shadow-md shadow-emerald-500/10 text-2xl shrink-0">
                  🛡️
                </div>
                <div>
                  <h3 className="font-black text-emerald-950 text-sm sm:text-base">Garansi Bersih, Higienis, & Halal GoFood</h3>
                  <p className="text-xs text-emerald-800 mt-1 max-w-md leading-relaxed">
                    Setiap menu mitra kami dilindungi asuransi pengantaran super-higienis. Box bersegel rapat dan driver bersertifikat vaksin lengkap.
                  </p>
                </div>
              </div>
              <span className="bg-emerald-600 text-white font-extrabold text-[11px] px-4.5 py-2.5 rounded-xl shrink-0">
                Layanan Terproteksi
              </span>
            </div>
          </div>
        ) : null}

        {/* 3. ORDER HISTORY VIEW */}
        {activeTab === "history" && (
          <OrderHistoryView
            history={historyList}
            onReorder={handleReorder}
            onRateOrder={handleRateOrder}
          />
        )}

        {/* 4. ONGOING ORDER TRACKING VIEW */}
        {activeTab === "tracking" && (
          ongoingOrder ? (
            <LiveTrackingView
              order={ongoingOrder}
              onSimulateNextStage={handleSimulateNextStage}
              onCancelOrder={handleCancelOrder}
            />
          ) : (
            <div className="py-20 text-center bg-white rounded-3xl border border-gray-150 max-w-lg mx-auto">
              <div className="h-16 w-16 bg-gray-50 text-gray-400 rounded-full flex items-center justify-center mb-4 mx-auto text-3xl">
                🛵
              </div>
              <h3 className="font-black text-gray-900 text-lg">Tidak Ada Orderan Berjalan</h3>
              <p className="text-xs text-gray-500 mt-2 max-w-xs mx-auto">
                Silakan jajan kuliner andalan terlebih dahulu untuk memantau pengiriman kurir real-time di halaman ini.
              </p>
              <button
                onClick={() => setActiveTab("home")}
                className="mt-6 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-5 py-3 rounded-xl shadow-lg transition-all"
              >
                Mulai Berbelanja
              </button>
            </div>
          )
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-gray-100 py-10 mt-20 text-gray-500 text-xs text-center shrink-0">
        <div className="max-w-7xl mx-auto px-4 space-y-4">
          <div className="flex justify-center space-x-6 text-gray-700 font-bold">
            <span className="hover:text-emerald-600 cursor-pointer">Tentang Kami</span>
            <span>•</span>
            <span className="hover:text-emerald-600 cursor-pointer">Pusat Bantuan</span>
            <span>•</span>
            <span className="hover:text-emerald-600 cursor-pointer">Syarat & Ketentuan</span>
            <span>•</span>
            <span className="hover:text-emerald-600 cursor-pointer">Kebijakan Privasi</span>
          </div>
          <p className="max-w-md mx-auto text-[11px] text-gray-400 leading-normal">
            GoFood Super-app Simulator Landing Board. Dikembangkan secara inklusif dengan standard visual modern, soft shadow, & mobile-first responsive.
          </p>
          <p className="text-[10px] text-gray-400/80 pt-2 font-mono">
            © 2026 PT GoFood Nusantara Kuliner. Terdaftar & Diawasi oleh Otoritas Kuliner Internasional.
          </p>
        </div>
      </footer>

      {/* --- INLINE OVERLAYS & PORTALS --- */}

      {/* A. Grouped Outlets Branch Selector Modal Sheet */}
      {inspectingRestaurant && (
        <BranchGroupModal
          restaurant={inspectingRestaurant}
          onClose={() => setInspectingRestaurant(null)}
          onSelectBranch={handleSelectBranch}
        />
      )}

      {/* B. Checkout Invoice Left/Right Panel Drawer */}
      <CheckoutInvoicePanel
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateCartItemQuantity={handleUpdateCartItemQuantity}
        onRemoveCartItem={handleRemoveCartItem}
        currentLocation={currentLocation}
        onCheckout={handleCheckout}
      />

      {/* C. User Identity Authentication Screen Overlay */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
        }}
      />
    </div>
  );
}
